#!/bin/bash
# JokkenClaude-App - Quick Start Script
# Uso: ./START.sh [opcion]

set -e

COLOR_RESET='\033[0m'
COLOR_GREEN='\033[0;32m'
COLOR_YELLOW='\033[1;33m'
COLOR_BLUE='\033[0;34m'
COLOR_RED='\033[0;31m'

echo -e "${COLOR_BLUE}"
echo "╔════════════════════════════════════════════════════╗"
echo "║     JokkenClaude-App - Iniciar Aplicación         ║"
echo "║          JPUNS Yukyu Management System             ║"
echo "╚════════════════════════════════════════════════════╝"
echo -e "${COLOR_RESET}"
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "docker-compose.yml" ]; then
    echo -e "${COLOR_RED}❌ Error: docker-compose.yml no encontrado"
    echo "Por favor ejecuta este script desde el directorio JokkenClaude-App${COLOR_RESET}"
    exit 1
fi

# Menu de opciones
show_menu() {
    echo -e "${COLOR_YELLOW}Selecciona una opción:${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_GREEN}1)${COLOR_RESET} Iniciar aplicación completa (Default)"
    echo -e "${COLOR_GREEN}2)${COLOR_RESET} Iniciar solo backend + database"
    echo -e "${COLOR_GREEN}3)${COLOR_RESET} Iniciar solo frontend"
    echo -e "${COLOR_GREEN}4)${COLOR_RESET} Ver estado de servicios"
    echo -e "${COLOR_GREEN}5)${COLOR_RESET} Detener todos los servicios"
    echo -e "${COLOR_GREEN}6)${COLOR_RESET} Ver logs (en vivo)"
    echo -e "${COLOR_GREEN}7)${COLOR_RESET} Reiniciar servicios"
    echo -e "${COLOR_GREEN}8)${COLOR_RESET} Limpiar y reiniciar desde cero"
    echo ""
}

start_full() {
    echo -e "${COLOR_YELLOW}▶ Iniciando aplicación completa...${COLOR_RESET}"
    docker-compose up -d

    echo ""
    echo -e "${COLOR_YELLOW}⏳ Esperando que los servicios estén listos...${COLOR_RESET}"
    sleep 5

    echo ""
    echo -e "${COLOR_GREEN}✅ Aplicación iniciada!${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BLUE}📍 Acceso a servicios:${COLOR_RESET}"
    echo -e "   🌐 Frontend:    ${COLOR_GREEN}http://localhost:3000${COLOR_RESET}"
    echo -e "   🔌 API:         ${COLOR_GREEN}http://localhost:8000${COLOR_RESET}"
    echo -e "   📚 API Docs:    ${COLOR_GREEN}http://localhost:8000/docs${COLOR_RESET}"
    echo -e "   📊 Grafana:     ${COLOR_GREEN}http://localhost:3001${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BLUE}🔑 Credenciales por defecto:${COLOR_RESET}"
    echo -e "   Usuario: ${COLOR_YELLOW}admin@example.com${COLOR_RESET}"
    echo -e "   Password: ${COLOR_YELLOW}admin_password_123${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_BLUE}💡 Comandos útiles:${COLOR_RESET}"
    echo -e "   Ver logs:       ${COLOR_YELLOW}docker-compose logs -f${COLOR_RESET}"
    echo -e "   Backend logs:   ${COLOR_YELLOW}docker-compose logs -f backend${COLOR_RESET}"
    echo -e "   Frontend logs:  ${COLOR_YELLOW}docker-compose logs -f frontend${COLOR_RESET}"
    echo -e "   Detener:        ${COLOR_YELLOW}docker-compose down${COLOR_RESET}"
    echo -e "   Init DB:        ${COLOR_YELLOW}docker-compose exec backend python -m alembic upgrade head${COLOR_RESET}"
    echo ""
}

start_backend_only() {
    echo -e "${COLOR_YELLOW}▶ Iniciando backend + database...${COLOR_RESET}"
    docker-compose up -d db redis backend
    echo -e "${COLOR_GREEN}✅ Backend iniciado!${COLOR_RESET}"
    echo -e "   API: ${COLOR_GREEN}http://localhost:8000/docs${COLOR_RESET}"
}

start_frontend_only() {
    echo -e "${COLOR_YELLOW}▶ Iniciando frontend...${COLOR_RESET}"
    docker-compose up -d frontend
    echo -e "${COLOR_GREEN}✅ Frontend iniciado!${COLOR_RESET}"
    echo -e "   URL: ${COLOR_GREEN}http://localhost:3000${COLOR_RESET}"
}

show_status() {
    echo -e "${COLOR_YELLOW}Estado de servicios:${COLOR_RESET}"
    echo ""
    docker-compose ps
}

stop_all() {
    echo -e "${COLOR_YELLOW}▶ Deteniendo todos los servicios...${COLOR_RESET}"
    docker-compose down
    echo -e "${COLOR_GREEN}✅ Servicios detenidos${COLOR_RESET}"
}

show_logs() {
    echo -e "${COLOR_YELLOW}▶ Mostrando logs en vivo (Ctrl+C para salir)...${COLOR_RESET}"
    echo ""
    docker-compose logs -f --tail=50
}

restart_services() {
    echo -e "${COLOR_YELLOW}▶ Reiniciando servicios...${COLOR_RESET}"
    docker-compose restart
    echo -e "${COLOR_GREEN}✅ Servicios reiniciados${COLOR_RESET}"
}

clean_restart() {
    echo -e "${COLOR_RED}⚠️ Esto va a eliminar todos los datos de la base de datos${COLOR_RESET}"
    read -p "¿Estás seguro? (s/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Ss]$ ]]; then
        echo -e "${COLOR_YELLOW}▶ Limpiando y reiniciando desde cero...${COLOR_RESET}"
        docker-compose down -v
        docker-compose up -d
        echo -e "${COLOR_GREEN}✅ Aplicación reiniciada desde cero${COLOR_RESET}"
    else
        echo "Operación cancelada"
    fi
}

# Procesar argumentos
if [ "$#" -eq 0 ]; then
    # Sin argumentos, mostrar menú
    show_menu
    read -p "Opción (1-8): " option
else
    option="$1"
fi

case $option in
    1|"")
        start_full
        ;;
    2)
        start_backend_only
        ;;
    3)
        start_frontend_only
        ;;
    4)
        show_status
        ;;
    5)
        stop_all
        ;;
    6)
        show_logs
        ;;
    7)
        restart_services
        ;;
    8)
        clean_restart
        ;;
    *)
        echo -e "${COLOR_RED}❌ Opción no válida${COLOR_RESET}"
        show_menu
        ;;
esac
