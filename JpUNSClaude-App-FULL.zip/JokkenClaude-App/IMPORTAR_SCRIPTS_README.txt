═══════════════════════════════════════════════════════════════════════════════
        SCRIPTS DE IMPORTACIÓN AUTOMÁTICA - JokkenClaude-App
═══════════════════════════════════════════════════════════════════════════════

🎯 PROPÓSITO

Estos scripts .bat automatizarán completamente la importación de tus datos
desde la carpeta DATABASEJP, manejando:

  • Candidatos con fotos OLE (Access)
  • Empleados HAKEN (派遣社員 - Dispatch workers)
  • Contratistas UKEOI (請負社員 - Contract workers)
  • Personal STAFF (スタッフ - Office/Admin staff)

═══════════════════════════════════════════════════════════════════════════════
        SCRIPTS DISPONIBLES
═══════════════════════════════════════════════════════════════════════════════

1. IMPORTAR_CANDIDATOS.bat
   └─ Importa candidatos desde Access con fotos OLE
   └─ Extrae automáticamente fotos del formato OLE
   └─ Convierte a Base64 → Visible en la app

2. IMPORTAR_EMPLEADOS.bat
   └─ Importa empleados HAKEN desde Excel
   └─ Aplica según plantilla del sistema

3. IMPORTAR_UKEOI.bat
   └─ Importa contratistas UKEOI desde Excel
   └─ Opcional (si tienes contratistas)

4. IMPORTAR_STAFF.bat
   └─ Importa personal STAFF desde Excel
   └─ Opcional (si tienes personal de oficina)

5. IMPORTAR_TODO.bat
   └─ Importa TODO en orden correcto
   └─ Recomendado para importación completa
   └─ Maneja automáticamente archivos faltantes

═══════════════════════════════════════════════════════════════════════════════
        ESTRUCTURA DE CARPETA DATABASEJP
═══════════════════════════════════════════════════════════════════════════════

C:\Users\TuNombre\DATABASEJP\
├─ base_datos.mdb (o .accdb)     ← Access con candidatos
│  └─ Tabla: candidates
│     ├─ id
│     ├─ full_name_kanji
│     ├─ full_name_kana
│     ├─ date_of_birth
│     ├─ gender
│     ├─ nationality
│     ├─ email
│     ├─ phone
│     ├─ address
│     └─ photo (OLE FORMAT) ← ⚠️ Script extrae automáticamente
│
├─ empleados.xlsx                 ← Empleados HAKEN
│  └─ Columnas según plantilla
│
├─ ukeoi.xlsx (OPCIONAL)          ← Contratistas UKEOI
│  └─ Columnas según plantilla
│
└─ staff.xlsx (OPCIONAL)          ← Personal STAFF
   └─ Columnas según plantilla

═══════════════════════════════════════════════════════════════════════════════
        PREPARACIÓN (Una sola vez)
═══════════════════════════════════════════════════════════════════════════════

1. CREAR CARPETA
   C:\Users\TuNombre\DATABASEJP\

2. COPIAR ARCHIVOS
   • base_datos.mdb o base_datos.accdb (con candidatos + fotos OLE)
   • empleados.xlsx (con empleados HAKEN)
   • ukeoi.xlsx (OPCIONAL - si tienes contratistas)
   • staff.xlsx (OPCIONAL - si tienes personal)

3. INSTALAR DEPENDENCIAS
   PowerShell (como Administrator):

   pip install pyodbc pandas Pillow requests

4. INSTALAR ACCESS DATABASE ENGINE (Windows)
   Descargar desde:
   https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255

   Elegir:
   • AccessDatabaseEngine_X64.exe (Windows 64-bit)
   • AccessDatabaseEngine.exe (Windows 32-bit)

5. INSTALAR PYTHON (si no lo tienes)
   https://www.python.org/downloads/
   ✓ Marcar: "Add Python to PATH"

═══════════════════════════════════════════════════════════════════════════════
        CÓMO USAR
═══════════════════════════════════════════════════════════════════════════════

🔷 OPCIÓN 1: IMPORTAR TODO (Recomendado)

1. Iniciar aplicación
   ./START.bat → Opción 1

2. Esperar a que cargue (15 segundos)

3. Obtener token
   • Abrir: http://localhost:3000
   • Login: admin@example.com / admin_password_123
   • Settings ⚙️ → API Token → Copiar

4. Ejecutar script
   • Doble-click en: IMPORTAR_TODO.bat
   • Pegar el token cuando lo pida
   • Esperar a que termine

5. Resultado
   ✓ Candidatos importados CON FOTOS
   ✓ Empleados importados
   ✓ Contratistas importados (si existen)
   ✓ Personal importado (si existe)


🔷 OPCIÓN 2: IMPORTAR SOLO LO QUE NECESITES

Solo candidatos:
   IMPORTAR_CANDIDATOS.bat

Solo empleados:
   IMPORTAR_EMPLEADOS.bat

Solo contratistas:
   IMPORTAR_UKEOI.bat

Solo personal:
   IMPORTAR_STAFF.bat


🔷 OPCIÓN 3: DESDE COMMAND LINE

Si prefieres usar PowerShell o CMD:

   cd C:\path\to\JokkenClaude-App
   python3 migracion_databasejp.py "tu_token" candidates
   python3 migracion_databasejp.py "tu_token" empleados_haken
   python3 migracion_databasejp.py "tu_token" ukeoi
   python3 migracion_databasejp.py "tu_token" staff

═══════════════════════════════════════════════════════════════════════════════
        VERIFICACIÓN
═══════════════════════════════════════════════════════════════════════════════

Después de importar, verifica en http://localhost:3000:

1. CANDIDATOS
   Reclutamiento → Candidatos
   ✓ Aparecen todos los candidatos
   ✓ Cada uno TIENE SU FOTO (extraída de OLE)

2. EMPLEADOS
   Personal → Empleados
   ✓ Aparecen todos los empleados HAKEN

3. CONTRATISTAS
   Personal → Contratistas
   ✓ Aparecen contratistas UKEOI (si los importaste)

4. PERSONAL
   Personal → Personal
   ✓ Aparece personal STAFF (si lo importaste)

═══════════════════════════════════════════════════════════════════════════════
        SOLUCIÓN DE PROBLEMAS
═══════════════════════════════════════════════════════════════════════════════

❌ "Python not found"
   → Instala Python: https://www.python.org/downloads/

❌ "pyodbc not found"
   → pip install pyodbc

❌ "Microsoft Access Driver not found"
   → Instala Access Database Engine (ver Preparación paso 4)

❌ "base_datos.mdb not found"
   → Copia el archivo a: C:\Users\TuNombre\DATABASEJP\

❌ "JPEG start marker not found in OLE object"
   → Las fotos están dañadas en Access
   → Intenta re-guardar las fotos en Access

❌ "Connection refused to localhost:8000"
   → La app no está corriendo
   → Ejecuta: ./START.bat

❌ "Token invalid"
   → Obtén token nuevo desde: Settings ⚙️ → API Token

═══════════════════════════════════════════════════════════════════════════════
        PRÓXIMOS PASOS DESPUÉS DE IMPORTAR
═══════════════════════════════════════════════════════════════════════════════

1. EVALUAR CANDIDATOS
   Reclutamiento → Candidatos
   → Click en cada candidato
   → Llenar entrevista + resultado
   → Guardar evaluación

2. APROBAR CANDIDATOS
   → Sistema auto-crea NYUUSHA (入社連絡票)

3. COMPLETAR DATOS DE EMPLEADO
   → Fábrica, hire_date, posición, salario, apartamento
   → Guardar

4. APROBAR NYUUSHA
   → Sistema crea empleado automáticamente
   → Genera deducción de renta

5. GESTIONAR APARTAMENTOS
   Apartamentos → Ocupación
   → Ver quién vive dónde
   → Ver cuánto paga (deducción automática)

═══════════════════════════════════════════════════════════════════════════════
        INFORMACIÓN TÉCNICA
═══════════════════════════════════════════════════════════════════════════════

OLE IMAGE EXTRACTION:
──────────────────
Los scripts manejan automáticamente la extracción de fotos OLE:

  Bytes OLE: [Header OLE][JPEG puro][Footer OLE]
            └ Basura      └ Imagen   └ Basura

  Script busca:
    JPEG_START = \xff\xd8\xff (SOI - Start of Image)
    JPEG_END   = \xff\xd9     (EOI - End of Image)

  Extrae solo el JPEG puro entre estos marcadores
  Valida que es imagen válida
  Convierte a Base64 → data:image/jpeg;base64,...

TIPOS DE EMPLEADOS:
─────────────────
  • HAKEN (派遣社員): Dispatch workers
  • UKEOI (請負社員): Contract/Outsourced workers
  • STAFF (スタッフ): Office/Admin staff

CAMPOS COPIADOS:
───────────────
  Candidato → Empleado:
    • Nombre (Kanji, Kana, Romaji)
    • Fecha nacimiento
    • Género, nacionalidad
    • Email, teléfono, dirección
    • Documentos (pasaporte, tarjeta residencia)
    • Foto
    + 20+ campos más

═══════════════════════════════════════════════════════════════════════════════
        CONTACTO / AYUDA
═══════════════════════════════════════════════════════════════════════════════

Si encuentras problemas:

1. Verifica la documentación:
   /docs/guides/DATABASEJP_IMPORT.md
   /docs/guides/VISUAL_INTERFACE.md

2. Revisa los logs del script:
   Los errores específicos aparecen en la ventana del CMD

3. Asegúrate que:
   • Carpeta DATABASEJP existe con archivos
   • Python está instalado y en PATH
   • Dependencias instaladas: pip install pyodbc pandas Pillow
   • Access Database Engine instalado
   • Token API es válido
   • App está corriendo en http://localhost:8000

═══════════════════════════════════════════════════════════════════════════════

Última actualización: 2025-11-22
Versión: 1.0.0
Status: ✓ Listo para Windows

═══════════════════════════════════════════════════════════════════════════════
