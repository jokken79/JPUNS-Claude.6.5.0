# Development Setup Guide

## Prerequisites

- **Docker & Docker Compose** (v20+)
- **Python 3.10+** (for local development)
- **Node.js 18+** (for frontend)
- **PostgreSQL client tools** (psql, optional)
- **Git** (for version control)

## Quick Start (5 minutes)

### 1. Clone and Setup

```bash
cd JokkenClaude-App
cp .env.example .env

# Start all services
docker-compose up -d

# Wait for services to be ready (30-60 seconds)
docker-compose exec backend python -m alembic upgrade head
```

### 2. Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **Admin Panel**: http://localhost:8000/admin

### 3. Default Credentials

**Backend API**:
- Test user: `admin@example.com`
- Password: `admin_password_123`

## Local Development (Without Docker)

### Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Setup database
export DATABASE_URL="postgresql://user:password@localhost:5432/jpuns"
python -m alembic upgrade head

# Run server
uvicorn app.main:app --reload
```

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Run development server
npm run dev
```

## Environment Configuration

See `.env.example` for all available variables:

```bash
# Database
DATABASE_URL=postgresql://postgres:password@localhost:5432/jpuns

# Redis
REDIS_URL=redis://localhost:6379

# JWT
SECRET_KEY=your-secret-key-here
ALGORITHM=HS256

# API Configuration
DEBUG=false
ENVIRONMENT=development

# External Services
AZURE_VISION_KEY=your-key-here
ZHIPU_API_KEY=your-key-here
```

## Verification

### Check Backend Health

```bash
curl http://localhost:8000/health
```

Expected response:
```json
{"status": "healthy", "database": "connected", "redis": "connected"}
```

### Check Frontend Load

```bash
curl http://localhost:3000
```

Should return HTML content.

## Running Tests

```bash
# Backend tests
docker-compose exec backend pytest

# Frontend tests
docker-compose exec frontend npm run test

# E2E tests
docker-compose exec frontend npm run test:e2e
```

## Useful Commands

```bash
# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Restart services
docker-compose restart backend
docker-compose restart frontend

# Access database
docker-compose exec db psql -U postgres -d jpuns

# Drop and recreate database
docker-compose exec backend python -m alembic downgrade base
docker-compose exec backend python -m alembic upgrade head

# Seed test data
docker-compose exec backend python -m app.scripts.seed
```

## Troubleshooting

**Port already in use?**
```bash
# Change port in docker-compose.yml
# OR stop conflicting service
lsof -i :3000  # Find what's using port 3000
kill -9 <PID>
```

**Database connection failed?**
```bash
# Ensure database is running
docker-compose ps db

# Check database logs
docker-compose logs db
```

**Dependencies issues?**
```bash
# Rebuild containers
docker-compose build --no-cache

# Remove volumes and restart
docker-compose down -v
docker-compose up -d
```

---

**Next**: [Running the Application](running-application.md)
