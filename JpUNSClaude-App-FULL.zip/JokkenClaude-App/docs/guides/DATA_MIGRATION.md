# 📊 Migración de Datos - De BD Existente a JokkenClaude-App

## 🎯 Tu Situación

- ✅ Tienes **candidatos con fotos** en una BD (JPUNS-Claude.6.0.2)
- ✅ Tienes **empleados** en Excel
- ❓ Necesitas importarlos a JokkenClaude-App

---

## 📋 PARTE 1: Importar Empleados desde Excel

### Paso 1: Descargar Plantilla

Descarga la plantilla Excel oficial del sistema:

```bash
GET /api/import-export/template/employees

# En curl:
curl -X GET "http://localhost:8000/api/import-export/template/employees" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  --output "plantilla_empleados.xlsx"
```

### Plantilla Incluye Estas Columnas

```
A: 派遣元ID (Factory ID) - Ej: FAC-001
B: 氏名 (Nombre Completo) - Ej: 山田太郎
C: フリガナ (Kana) - Ej: ヤマダタロウ
D: ローマ字 (Romaji) - Ej: Yamada Taro
E: 生年月日 (Fecha Nacimiento) - YYYY-MM-DD
F: 性別 (Género) - 男性/女性
G: 国籍 (Nacionalidad) - 日本/Vietnam/Etc
H: 郵便番号 (Código Postal)
I: 住所 (Dirección)
J: 携帯電話 (Celular)
K: 電話番号 (Teléfono)
L: メール (Email)
M: 在留カード番号 (Residence Card)
N: ビザ種類 (Visa Type)
O: ビザ期限 (Visa Expiry) - YYYY-MM-DD
```

### Paso 2: Mapear Tus Datos al Formato

Si tienes datos en Excel con diferentes columnas, mapéalos así:

**Tu Excel** → **Plantilla Sistema**
```
ID del empleado → 派遣元ID
Nombre completo → 氏名
Nombre en kana → フリガナ
Nombre romaji → ローマ字
Fecha de nac. → 生年月日
Sexo → 性別
Etc.
```

**Ejemplo en Python:**
```python
import pandas as pd

# Leer tu Excel
df_original = pd.read_excel("mis_empleados.xlsx")

# Mapear columnas
df_mapeado = pd.DataFrame({
    "派遣元ID": df_original["employee_id"],
    "氏名": df_original["full_name"],
    "フリガナ": df_original["kana_name"],
    "ローマ字": df_original["romaji_name"],
    "生年月日": df_original["date_of_birth"],
    "性別": df_original["gender"],
    "国籍": df_original["nationality"],
    "郵便番号": df_original["postal_code"],
    "住所": df_original["address"],
    "携帯電話": df_original["mobile"],
    "電話番号": df_original["phone"],
    "メール": df_original["email"],
    "在留カード番号": df_original["residence_card"],
    "ビザ種類": df_original["visa_type"],
    "ビザ期限": df_original["visa_expiry"],
})

# Guardar en formato que acepta el sistema
df_mapeado.to_excel("empleados_importar.xlsx", index=False)
```

### Paso 3: Importar Empleados

Una vez que tu Excel está en el formato correcto:

```bash
POST /api/import-export/employees

# En curl:
curl -X POST "http://localhost:8000/api/import-export/employees" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@empleados_importar.xlsx"
```

**Respuesta:**
```json
{
  "status": "success",
  "data": {
    "total_rows": 150,
    "successful_imports": 148,
    "failed_imports": 2,
    "errors": [
      {"row": 5, "error": "Invalid date format"},
      {"row": 23, "error": "Duplicate employee ID"}
    ]
  }
}
```

### Paso 4: Verificar Importación

```bash
# Ver empleados importados
GET /api/employees

# Ver un empleado específico
GET /api/employees/{employee_id}
```

---

## 👥 PARTE 2: Importar Candidatos desde BD Existente

### Opción A: Script de Migración desde JPUNS-Claude.6.0.2

Si tienes JPUNS-Claude.6.0.2 con candidatos en BD:

**Script Python para extraer:**

```python
import psycopg2
from psycopg2.extras import RealDictCursor
import base64
from pathlib import Path

# Conexión a BD original (JPUNS)
conn_jpuns = psycopg2.connect(
    host="localhost",
    database="jpuns",
    user="postgres",
    password="your_password"
)

# Obtener candidatos
cursor = conn_jpuns.cursor(cursor_factory=RealDictCursor)
cursor.execute("""
    SELECT
        id,
        full_name_kanji,
        full_name_kana,
        date_of_birth,
        gender,
        nationality,
        email,
        phone,
        address,
        passport_number,
        residence_card_number,
        residence_status,
        photo_data_url
    FROM candidates
    WHERE deleted_at IS NULL
    ORDER BY created_at DESC
""")

candidatos = cursor.fetchall()

# Convertir a formato para importar
import_data = []
for idx, candidato in enumerate(candidatos):
    import_data.append({
        "rirekisho_id": f"RIR-{str(idx+1).zfill(5)}",
        "form_data": {
            "full_name_kanji": candidato["full_name_kanji"],
            "full_name_kana": candidato["full_name_kana"],
            "date_of_birth": candidato["date_of_birth"].isoformat() if candidato["date_of_birth"] else None,
            "gender": candidato["gender"],
            "nationality": candidato["nationality"],
            "email": candidato["email"],
            "phone": candidato["phone"],
            "address": candidato["address"],
            "passport_number": candidato["passport_number"],
            "residence_card_number": candidato["residence_card_number"],
            "residence_status": candidato["residence_status"],
        },
        "photo_data_url": candidato["photo_data_url"]  # Ya está en Base64
    })

# Importar a JokkenClaude-App
import requests

url = "http://localhost:8000/api/candidates/rirekisho/form"
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

for candidato in import_data:
    response = requests.post(url, json=candidato, headers=headers)
    if response.status_code == 201:
        print(f"✓ {candidato['form_data']['full_name_kanji']} importado")
    else:
        print(f"✗ Error: {response.text}")
```

### Opción B: CSV para Importar Candidatos (Manual)

Si no tienes acceso directo a BD, prepara CSV:

```csv
Nombre Kanji,Nombre Kana,Fecha Nac,Género,Nacionalidad,Email,Teléfono,Dirección,Foto Path
山田太郎,やまだたろう,1990-05-15,Masculino,Japonés,yamada@ex.com,090-1234,Fukuoka,/path/to/foto1.jpg
鈴木花子,すずきはなこ,1992-03-20,Femenino,Japonés,suzuki@ex.com,090-5678,Fukuoka,/path/to/foto2.jpg
```

**Script para convertir CSV a formato API:**

```python
import csv
import requests
import base64

url = "http://localhost:8000/api/candidates/rirekisho/form"
token = "YOUR_TOKEN"
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# Leer CSV
with open("candidatos.csv", encoding='utf-8') as f:
    reader = csv.DictReader(f)

    for idx, row in enumerate(reader, 1):
        # Convertir foto a Base64
        photo_data_url = None
        if row["Foto Path"]:
            try:
                with open(row["Foto Path"], "rb") as img:
                    img_data = base64.b64encode(img.read()).decode('utf-8')
                    photo_data_url = f"data:image/jpeg;base64,{img_data}"
            except:
                print(f"⚠️ Foto no encontrada: {row['Foto Path']}")

        # Preparar datos
        payload = {
            "rirekisho_id": f"RIR-{str(idx).zfill(5)}",
            "form_data": {
                "full_name_kanji": row["Nombre Kanji"],
                "full_name_kana": row["Nombre Kana"],
                "date_of_birth": row["Fecha Nac"],
                "gender": row["Género"],
                "nationality": row["Nacionalidad"],
                "email": row["Email"],
                "phone": row["Teléfono"],
                "address": row["Dirección"],
            },
            "photo_data_url": photo_data_url
        }

        # Importar
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 201:
            print(f"✓ {row['Nombre Kanji']} importado")
        else:
            print(f"✗ {row['Nombre Kanji']}: {response.text}")
```

---

## 📸 PARTE 3: Manejo Especial de Fotos

### Si Las Fotos Están en Archivos

**Convertir fotos a Base64:**

```python
import base64
import os

def foto_a_base64(ruta_foto):
    """Convierte una foto a data URL Base64"""
    if not os.path.exists(ruta_foto):
        return None

    with open(ruta_foto, "rb") as img_file:
        img_data = base64.b64encode(img_file.read()).decode('utf-8')

        # Determinar MIME type
        ext = os.path.splitext(ruta_foto)[1].lower()
        mime_types = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.webp': 'image/webp'
        }
        mime = mime_types.get(ext, 'image/jpeg')

        return f"data:{mime};base64,{img_data}"

# Uso
foto_url = foto_a_base64("/path/to/mi_foto.jpg")
print(foto_url)  # data:image/jpeg;base64,/9j/4AAQSkZJRg...
```

### Si Las Fotos Ya Están en Base64

Si ya tienes fotos en Base64, úsalas directamente:

```python
payload = {
    "form_data": {...},
    "photo_data_url": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."  # ← Ya en Base64
}
```

---

## 🔄 PARTE 4: Flujo Completo de Migración

### Paso 1: Preparar Datos

```
BD Existente (JPUNS-Claude.6.0.2)
    ↓
Excel Original (empleados.xlsx)
    ↓
Extraer/Limpiar datos
    ↓
Mapear a formato del sistema
    ↓
Crear archivos intermedios
```

### Paso 2: Importar Empleados

```bash
# 1. Descargar plantilla
curl -X GET "http://localhost:8000/api/import-export/template/employees" \
  -o plantilla.xlsx

# 2. Mapear tus datos a la plantilla

# 3. Importar
curl -X POST "http://localhost:8000/api/import-export/employees" \
  -F "file=@empleados_mapeados.xlsx"
```

### Paso 3: Importar Candidatos

```bash
# Con script Python (Opción A o B)
python3 migracion_candidatos.py
```

---

## 🧪 Script Completo: Migración Todo-en-Uno

```python
#!/usr/bin/env python3
"""
Migracion completa: Excel empleados + Candidatos desde BD
"""

import psycopg2
from psycopg2.extras import RealDictCursor
import pandas as pd
import requests
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataMigrator:
    def __init__(self, api_url, token, jpuns_conn_str):
        self.api_url = api_url
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        self.conn_jpuns = psycopg2.connect(jpuns_conn_str)

    def migrate_employees_from_excel(self, excel_path):
        """Importar empleados desde Excel"""
        logger.info(f"Importando empleados desde {excel_path}")

        # Leer Excel
        df = pd.read_excel(excel_path)

        # Enviar archivo
        with open(excel_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(
                f"{self.api_url}/api/import-export/employees",
                headers={"Authorization": f"Bearer {self.token}"},
                files=files
            )

        if response.status_code == 200:
            result = response.json()
            logger.info(f"✓ {result['data']['successful_imports']} empleados importados")
            if result['data']['failed_imports'] > 0:
                logger.warning(f"✗ {result['data']['failed_imports']} fallaron")
                for error in result['data']['errors']:
                    logger.error(f"  Row {error['row']}: {error['error']}")
        else:
            logger.error(f"Error: {response.text}")

    def migrate_candidates_from_jpuns(self):
        """Importar candidatos desde BD original"""
        logger.info("Importando candidatos desde JPUNS...")

        cursor = self.conn_jpuns.cursor(cursor_factory=RealDictCursor)
        cursor.execute("""
            SELECT * FROM candidates
            WHERE deleted_at IS NULL
            ORDER BY created_at DESC
        """)

        candidatos = cursor.fetchall()
        logger.info(f"Encontrados {len(candidatos)} candidatos")

        for idx, candidato in enumerate(candidatos):
            payload = {
                "rirekisho_id": f"RIR-{str(idx+1).zfill(5)}",
                "form_data": {
                    "full_name_kanji": candidato["full_name_kanji"],
                    "full_name_kana": candidato["full_name_kana"],
                    "date_of_birth": candidato["date_of_birth"].isoformat() if candidato["date_of_birth"] else None,
                    "gender": candidato["gender"],
                    "nationality": candidato["nationality"],
                    "email": candidato["email"],
                    "phone": candidato["phone"],
                    "address": candidato["address"],
                },
                "photo_data_url": candidato["photo_data_url"]
            }

            response = requests.post(
                f"{self.api_url}/api/candidates/rirekisho/form",
                headers=self.headers,
                json=payload
            )

            if response.status_code == 201:
                logger.info(f"✓ {candidato['full_name_kanji']} importado")
            else:
                logger.error(f"✗ {candidato['full_name_kanji']}: {response.text}")

        cursor.close()

# Uso
if __name__ == "__main__":
    migrator = DataMigrator(
        api_url="http://localhost:8000",
        token="YOUR_TOKEN_HERE",
        jpuns_conn_str="postgresql://user:password@localhost/jpuns"
    )

    # 1. Importar empleados
    migrator.migrate_employees_from_excel("mis_empleados.xlsx")

    # 2. Importar candidatos
    migrator.migrate_candidates_from_jpuns()

    print("\n✓ Migración completada!")
```

---

## ✅ Checklist de Migración

- [ ] Descargar plantilla de empleados
- [ ] Mapear datos de Excel a formato del sistema
- [ ] Validar que todas las fechas estén en formato YYYY-MM-DD
- [ ] Validar que géneros estén en formato correcto (男性/女性 o Male/Female)
- [ ] Importar empleados desde Excel
- [ ] Verificar que empleados se importaron correctamente
- [ ] Extraer candidatos de BD original
- [ ] Convertir fotos a Base64 si es necesario
- [ ] Importar candidatos
- [ ] Verificar que candidatos tienen fotos
- [ ] Evaluar candidatos
- [ ] Aprobar candidatos → Crear NYUUSHA
- [ ] Listo para usar

---

## 🛠️ Troubleshooting de Migración

### ❌ ERROR: "Invalid date format"

**Solución:**
```
Las fechas deben estar en formato: YYYY-MM-DD
Ej: 1990-05-15

Si están en otro formato, convertir:
- Excel: =TEXT(A1,"YYYY-MM-DD")
- Python: pd.to_datetime(df['fecha']).dt.strftime('%Y-%m-%d')
```

### ❌ ERROR: "Duplicate employee ID"

**Solución:**
```
Ya existe un empleado con ese ID
Opciones:
1. Usar ID único para cada empleado
2. Limpiar duplicados antes de importar
3. Actualizar registro existente en lugar de importar
```

### ❌ ERROR: "Invalid photo format"

**Solución:**
```
La foto no está en formato válido
Asegurar:
1. Base64 válido
2. Data URL correcta: data:image/jpeg;base64,...
3. Tamaño máximo 10 MB
4. Formato: JPG, PNG, WebP
```

### ❌ ERROR: "Photo too large"

**Solución:**
```python
# Comprimir foto
from PIL import Image
import io
import base64

def comprimir_foto(foto_data_url, max_width=800, max_height=1000, quality=85):
    # Extraer Base64
    base64_str = foto_data_url.split(',')[1]
    img_data = base64.b64decode(base64_str)

    # Cargar imagen
    img = Image.open(io.BytesIO(img_data))

    # Redimensionar
    img.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)

    # Guardar
    output = io.BytesIO()
    img.save(output, format='JPEG', quality=quality)

    # Convertir a Base64
    compressed_b64 = base64.b64encode(output.getvalue()).decode('utf-8')
    return f"data:image/jpeg;base64,{compressed_b64}"

# Uso
foto_comprimida = comprimir_foto(foto_data_url)
```

---

## 📊 Endpoints de Importación

| Operación | Endpoint | Método | Notas |
|-----------|----------|--------|-------|
| Importar empleados | `/api/import-export/employees` | POST | Excel: .xlsx, .xls |
| Plantilla empleados | `/api/import-export/template/employees` | GET | Descargar Excel |
| Importar candidato | `/api/candidates/rirekisho/form` | POST | JSON con datos + foto |
| Importar tarjetas | `/api/import-export/timer-cards` | POST | Excel con horarios |

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
**Estado**: Completamente Documentado ✅
