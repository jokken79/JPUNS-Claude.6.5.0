# 🗄️ Importar desde Carpeta DATABASEJP - Guía Completa

## 🎯 Tu Setup

```
/home/user/DATABASEJP/
├── base_datos.mdb (o .accdb)    ← Access con candidatos + fotos OLE
└── empleados.xlsx                ← Excel con empleados
```

El sistema detectará automáticamente qué archivos hay y los procesará.

---

## ⚠️ El Problema: Fotos OLE en Access

### ¿Qué son las Fotos OLE?

Las fotos guardadas en Access como **OLE (Object Linking and Embedding)** tienen:
- Bytes especiales al inicio/final (OLE header/footer)
- No son JPEG puro
- Necesitan descomposición especial
- No se pueden usar directamente

### La Solución

Extraer la **imagen JPEG pura** del objeto OLE y convertir a Base64.

---

## 🛠️ Script Automático: `migracion_databasejp.py`

Crea este archivo en la raíz de JokkenClaude-App:

```python
#!/usr/bin/env python3
"""
Migración automática desde carpeta DATABASEJP
- Lee Access con candidatos + fotos OLE
- Lee Excel con empleados
- Importa a JokkenClaude-App automáticamente
"""

import os
import json
import logging
import base64
import requests
import pandas as pd
from pathlib import Path
from typing import Optional, Dict, List
import pyodbc
from PIL import Image
import io

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class OLEImageExtractor:
    """Extrae imágenes JPEG puras de objetos OLE en Access"""

    # Signatures de imagen
    JPEG_START = b'\xff\xd8\xff'  # SOI (Start of Image)
    JPEG_END = b'\xff\xd9'         # EOI (End of Image)

    @staticmethod
    def extract_jpeg_from_ole(ole_bytes: bytes) -> Optional[bytes]:
        """
        Extrae JPEG puro de objeto OLE

        Las fotos OLE en Access tienen:
        - Bytes OLE iniciales (header)
        - JPEG embebido
        - Bytes OLE finales (footer)

        Encuentra y extrae solo la parte JPEG
        """
        if not ole_bytes or len(ole_bytes) < 100:
            return None

        try:
            # Buscar inicio de JPEG
            start_idx = ole_bytes.find(OLEImageExtractor.JPEG_START)
            if start_idx == -1:
                logger.warning("JPEG start marker not found in OLE object")
                return None

            # Buscar fin de JPEG
            end_idx = ole_bytes.find(OLEImageExtractor.JPEG_END, start_idx)
            if end_idx == -1:
                logger.warning("JPEG end marker not found in OLE object")
                return None

            # Extraer JPEG (incluir end marker)
            end_idx += len(OLEImageExtractor.JPEG_END)
            jpeg_data = ole_bytes[start_idx:end_idx]

            # Validar que es JPEG válido
            try:
                Image.open(io.BytesIO(jpeg_data))
                logger.info(f"✓ JPEG válido extraído ({len(jpeg_data)} bytes)")
                return jpeg_data
            except Exception as e:
                logger.error(f"✗ JPEG extraído es inválido: {e}")
                return None

        except Exception as e:
            logger.error(f"Error extrayendo JPEG de OLE: {e}")
            return None

    @staticmethod
    def ole_to_base64(ole_bytes: bytes) -> Optional[str]:
        """Convierte OLE → JPEG → Base64"""
        jpeg_data = OLEImageExtractor.extract_jpeg_from_ole(ole_bytes)
        if not jpeg_data:
            return None

        b64_str = base64.b64encode(jpeg_data).decode('utf-8')
        return f"data:image/jpeg;base64,{b64_str}"


class AccessDatabaseReader:
    """Lee datos de base de datos Access (.mdb/.accdb)"""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn_string = None
        self._setup_connection_string()

    def _setup_connection_string(self):
        """Configura connection string según versión de Access"""
        if self.db_path.endswith('.mdb'):
            # Access 2003 y anteriores
            self.conn_string = f"Driver={{Microsoft Access Driver (*.mdb)}};DBQ={self.db_path};"
        elif self.db_path.endswith('.accdb'):
            # Access 2007+
            self.conn_string = f"Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.db_path};"
        else:
            raise ValueError("Solo .mdb y .accdb son soportados")

    def get_candidates_with_photos(self) -> List[Dict]:
        """
        Lee candidatos de Access con fotos OLE

        Busca tabla "candidates" con columnas:
        - id, full_name_kanji, full_name_kana, date_of_birth,
          gender, nationality, email, phone, address, photo (OLE)
        """
        candidates = []

        try:
            conn = pyodbc.connect(self.conn_string)
            cursor = conn.cursor()

            # Leer tabla candidates
            cursor.execute("SELECT * FROM candidates")
            columns = [desc[0] for desc in cursor.description]

            logger.info(f"Columnas encontradas: {columns}")

            for row in cursor.fetchall():
                candidate_dict = dict(zip(columns, row))

                # Si tiene foto OLE, extraer
                photo_data_url = None
                if 'photo' in candidate_dict or 'photo_data' in candidate_dict:
                    photo_key = 'photo' if 'photo' in candidate_dict else 'photo_data'
                    ole_data = candidate_dict.get(photo_key)

                    if ole_data:
                        logger.info(f"Procesando foto OLE para {candidate_dict.get('full_name_kanji')}")
                        photo_data_url = OLEImageExtractor.ole_to_base64(ole_data)

                        if photo_data_url:
                            logger.info(f"✓ Foto extraída exitosamente")
                        else:
                            logger.warning(f"✗ No se pudo extraer foto")

                candidates.append({
                    "id": candidate_dict.get("id"),
                    "full_name_kanji": candidate_dict.get("full_name_kanji"),
                    "full_name_kana": candidate_dict.get("full_name_kana"),
                    "date_of_birth": candidate_dict.get("date_of_birth"),
                    "gender": candidate_dict.get("gender"),
                    "nationality": candidate_dict.get("nationality"),
                    "email": candidate_dict.get("email"),
                    "phone": candidate_dict.get("phone"),
                    "address": candidate_dict.get("address"),
                    "photo_data_url": photo_data_url
                })

            conn.close()
            logger.info(f"✓ {len(candidates)} candidatos leídos de Access")
            return candidates

        except Exception as e:
            logger.error(f"Error leyendo Access: {e}")
            logger.info("Asegurate que:")
            logger.info("  1. Access está instalado en Windows")
            logger.info("  2. La ruta del archivo es correcta")
            logger.info("  3. La tabla se llama 'candidates'")
            return []


class JokkenImporter:
    """Importa datos a JokkenClaude-App"""

    def __init__(self, api_url: str, token: str):
        self.api_url = api_url
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

    def import_employees_from_excel(self, excel_path: str) -> Dict:
        """Importa empleados desde Excel"""
        logger.info(f"Importando empleados desde {excel_path}")

        try:
            with open(excel_path, 'rb') as f:
                files = {'file': f}
                headers_file = {"Authorization": f"Bearer {self.token}"}

                response = requests.post(
                    f"{self.api_url}/api/import-export/employees",
                    headers=headers_file,
                    files=files
                )

            if response.status_code == 200:
                result = response.json()
                success = result.get('data', {}).get('successful_imports', 0)
                failed = result.get('data', {}).get('failed_imports', 0)

                logger.info(f"✓ {success} empleados importados")
                if failed > 0:
                    logger.warning(f"✗ {failed} empleados fallaron")
                    for error in result.get('data', {}).get('errors', []):
                        logger.error(f"  Row {error.get('row')}: {error.get('error')}")

                return {"success": True, "imported": success, "failed": failed}
            else:
                logger.error(f"Error importando empleados: {response.text}")
                return {"success": False, "error": response.text}

        except Exception as e:
            logger.error(f"Error procesando Excel: {e}")
            return {"success": False, "error": str(e)}

    def import_candidate(self, candidate: Dict) -> bool:
        """Importa un candidato a JokkenClaude-App"""
        try:
            payload = {
                "rirekisho_id": f"RIR-{str(candidate.get('id', 0)).zfill(5)}",
                "form_data": {
                    "full_name_kanji": candidate.get("full_name_kanji"),
                    "full_name_kana": candidate.get("full_name_kana"),
                    "date_of_birth": str(candidate.get("date_of_birth")) if candidate.get("date_of_birth") else None,
                    "gender": candidate.get("gender"),
                    "nationality": candidate.get("nationality"),
                    "email": candidate.get("email"),
                    "phone": candidate.get("phone"),
                    "address": candidate.get("address"),
                },
                "photo_data_url": candidate.get("photo_data_url")
            }

            response = requests.post(
                f"{self.api_url}/api/candidates/rirekisho/form",
                headers=self.headers,
                json=payload
            )

            if response.status_code == 201:
                logger.info(f"✓ {candidate.get('full_name_kanji')} importado")
                return True
            else:
                logger.error(f"✗ {candidate.get('full_name_kanji')}: {response.text}")
                return False

        except Exception as e:
            logger.error(f"Error importando candidato: {e}")
            return False

    def import_candidates(self, candidates: List[Dict]) -> Dict:
        """Importa múltiples candidatos"""
        successful = 0
        failed = 0

        for candidate in candidates:
            if self.import_candidate(candidate):
                successful += 1
            else:
                failed += 1

        logger.info(f"\nResumen candidatos:")
        logger.info(f"✓ {successful} importados")
        if failed > 0:
            logger.warning(f"✗ {failed} fallaron")

        return {"successful": successful, "failed": failed}


class DatabaseJPMigrator:
    """Orquestador principal de migración desde DATABASEJP"""

    def __init__(self, databasejp_path: str, api_url: str, token: str):
        self.databasejp_path = Path(databasejp_path)
        self.api_url = api_url
        self.token = token

        if not self.databasejp_path.exists():
            raise ValueError(f"Carpeta {databasejp_path} no existe")

        logger.info(f"Inicializando migración desde {self.databasejp_path}")

    def find_files(self) -> Dict[str, Optional[Path]]:
        """Busca archivos en DATABASEJP"""
        files = {
            "access_db": None,
            "excel_employees": None
        }

        # Buscar Access
        for ext in ['*.mdb', '*.accdb']:
            for file in self.databasejp_path.glob(ext):
                files["access_db"] = file
                logger.info(f"✓ Encontrado: {file.name}")
                break

        # Buscar Excel
        for ext in ['*.xlsx', '*.xls']:
            for file in self.databasejp_path.glob(ext):
                files["excel_employees"] = file
                logger.info(f"✓ Encontrado: {file.name}")
                break

        return files

    def run(self):
        """Ejecuta migración completa"""
        logger.info("\n" + "="*60)
        logger.info("INICIANDO MIGRACIÓN DESDE DATABASEJP")
        logger.info("="*60 + "\n")

        # Encontrar archivos
        files = self.find_files()

        if not files["access_db"] and not files["excel_employees"]:
            logger.error("✗ No se encontraron archivos en DATABASEJP")
            logger.info("Esperado:")
            logger.info("  - base_datos.mdb o base_datos.accdb")
            logger.info("  - empleados.xlsx o empleados.xls")
            return

        # Importar empleados
        if files["excel_employees"]:
            logger.info("\n" + "-"*60)
            logger.info("FASE 1: Importar Empleados")
            logger.info("-"*60 + "\n")

            importer = JokkenImporter(self.api_url, self.token)
            result = importer.import_employees_from_excel(str(files["excel_employees"]))

            if not result["success"]:
                logger.error(f"✗ Fallo importación de empleados: {result.get('error')}")
        else:
            logger.warning("⚠️ No se encontró archivo Excel de empleados")

        # Importar candidatos
        if files["access_db"]:
            logger.info("\n" + "-"*60)
            logger.info("FASE 2: Importar Candidatos con Fotos OLE")
            logger.info("-"*60 + "\n")

            try:
                # Leer Access
                reader = AccessDatabaseReader(str(files["access_db"]))
                candidates = reader.get_candidates_with_photos()

                if candidates:
                    # Importar candidatos
                    importer = JokkenImporter(self.api_url, self.token)
                    result = importer.import_candidates(candidates)
                else:
                    logger.error("✗ No se encontraron candidatos en Access")

            except ImportError as e:
                logger.error(f"✗ Error: {e}")
                logger.info("\nPara Windows con Access instalado:")
                logger.info("  pip install pyodbc")
                logger.info("\nSi no tienes Access, usa opción alternativa:")
                logger.info("  Guarda candidatos en CSV en lugar de Access")

        logger.info("\n" + "="*60)
        logger.info("✓ MIGRACIÓN COMPLETADA")
        logger.info("="*60)


# Main
if __name__ == "__main__":
    import sys

    # Configuración
    DATABASEJP_PATH = "/home/user/DATABASEJP"
    API_URL = "http://localhost:8000"
    TOKEN = "YOUR_TOKEN_HERE"  # Reemplazar con token real

    # Validar argumentos
    if len(sys.argv) > 1:
        TOKEN = sys.argv[1]

    if TOKEN == "YOUR_TOKEN_HERE":
        print("ERROR: Reemplaza YOUR_TOKEN_HERE con tu token real")
        print("Uso: python3 migracion_databasejp.py <your_token>")
        sys.exit(1)

    # Ejecutar migración
    try:
        migrator = DatabaseJPMigrator(DATABASEJP_PATH, API_URL, TOKEN)
        migrator.run()
    except Exception as e:
        logger.error(f"Error fatal: {e}")
        sys.exit(1)
```

---

## 📁 Paso 1: Crear Carpeta DATABASEJP

```bash
mkdir /home/user/DATABASEJP
```

---

## 📋 Paso 2: Agregar Archivos

Coloca en `/home/user/DATABASEJP/`:

```
DATABASEJP/
├── base_datos.mdb          # Tu Access con candidatos + fotos OLE
│   └── Tabla: candidates
│       ├── id
│       ├── full_name_kanji
│       ├── full_name_kana
│       ├── date_of_birth
│       ├── gender
│       ├── nationality
│       ├── email
│       ├── phone
│       ├── address
│       └── photo (OLE)      ← Fotos como objetos OLE
│
└── empleados.xlsx           # Tu Excel con empleados
    └── Columnas según plantilla (ver más abajo)
```

---

## 📊 Formato: Excel de Empleados

El Excel debe tener estas columnas:

```
派遣元ID | 氏名 | フリガナ | ローマ字 | 生年月日 | 性別 | 国籍 | 住所 | 携帯 | メール
FAC-001 | 山田太郎 | ヤマダ | Yamada | 1990-05-15 | 男性 | 日本 | 福岡 | 090-1234 | yamada@ex.com
```

---

## 🔧 Instalación de Dependencias

En Windows (en PowerShell como Administrator):

```bash
# Instalar módulos Python necesarios
pip install pyodbc pandas Pillow requests

# Para Access, también necesitas:
# Microsoft Access Database Engine
# Descargar desde: https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255
```

---

## 🚀 Ejecutar Migración

### Paso 1: Obtener Token

```bash
# En la app web:
# 1. Login con admin
# 2. Settings → API Token → Copiar token
```

### Paso 2: Ejecutar Script

```bash
python3 migracion_databasejp.py <tu_token_aqui>

# Ejemplo:
python3 migracion_databasejp.py "eyJhbGciOiJIUzI1NiIsInR5..."
```

### Paso 3: Ver Resultados

```
======================================================
INICIANDO MIGRACIÓN DESDE DATABASEJP
======================================================

✓ Encontrado: base_datos.mdb
✓ Encontrado: empleados.xlsx

----------------------------------------------------
FASE 1: Importar Empleados
----------------------------------------------------

✓ 150 empleados importados

----------------------------------------------------
FASE 2: Importar Candidatos con Fotos OLE
----------------------------------------------------

✓ Candidato 1: 山田太郎
  Procesando foto OLE...
  ✓ JPEG válido extraído (245732 bytes)
  ✓ Foto extraída exitosamente
  ✓ 山田太郎 importado

✓ 85 candidatos importados
✗ 2 fallaron

======================================================
✓ MIGRACIÓN COMPLETADA
======================================================
```

---

## 🔍 ¿Qué Hace el Script?

### 1. Lee Access
```python
# Conecta a base_datos.mdb/.accdb
# Lee tabla: candidates
# Extrae: nombre, datos, FOTO OLE
```

### 2. Procesa Fotos OLE
```python
# OLE Bytes: [header OLE][JPEG puro][footer OLE]
#
# El script busca los marcadores JPEG:
# - JPEG_START: \xff\xd8\xff (SOI)
# - JPEG_END:   \xff\xd9     (EOI)
#
# Extrae solo el JPEG puro
# Valida que es imagen válida
# Convierte a Base64
```

### 3. Lee Excel
```python
# Abre empleados.xlsx
# Mapea columnas automáticamente
# Prepara datos para importación
```

### 4. Importa a JokkenClaude-App
```python
# POST /api/import-export/employees
# POST /api/candidates/rirekisho/form
#
# Espera confirmación de cada importación
# Reporta errores específicos
```

---

## ⚠️ Solución de Problemas

### ❌ "pyodbc not found"

```bash
pip install pyodbc
```

### ❌ "Microsoft Access Driver not found" (Windows)

Descargar e instalar:
```
https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255
```

Elegir versión según tu Windows:
- **64-bit**: AccessDatabaseEngine_X64.exe
- **32-bit**: AccessDatabaseEngine.exe

### ❌ "Connection failed"

Verificar:
1. Ruta del archivo es correcta
2. Archivo no está corrupto
3. Tabla se llama exactamente "candidates"
4. Access está cerrado (no bloqueando archivo)

### ❌ "JPEG start marker not found"

Las fotos están dañadas o no son JPEG. Soluciones:
1. Verificar en Access que las fotos se ven bien
2. Re-guardar fotos como JPEG puro
3. Si es necesario, exportar fotos a carpeta y usar CSV

### ❌ "Token invalid"

```bash
# Obtener token nuevo
# 1. Abrir app en http://localhost:3000
# 2. Login con admin
# 3. Settings → API Token → Copiar
# 4. Ejecutar: python3 migracion_databasejp.py <nuevo_token>
```

---

## 🎯 Alternativa si Access Causa Problemas

Si no puedes/quieres usar Access, exporta a CSV:

```csv
id,full_name_kanji,full_name_kana,date_of_birth,gender,nationality,email,phone,address,foto_path
1,山田太郎,やまだたろう,1990-05-15,Masculino,Japonés,yamada@ex.com,090-1234,福岡,/path/to/foto1.jpg
2,鈴木花子,すずきはなこ,1992-03-20,Femenino,Japonés,suzuki@ex.com,090-5678,福岡,/path/to/foto2.jpg
```

Y usa el script CSV en lugar de Access.

---

## 📋 Checklist Final

- [ ] Carpeta DATABASEJP creada
- [ ] base_datos.mdb/.accdb copiado
- [ ] empleados.xlsx copiado
- [ ] migracion_databasejp.py descargado
- [ ] Dependencias instaladas (pip install pyodbc pandas Pillow)
- [ ] Access Database Engine instalado (Windows)
- [ ] Token API obtenido
- [ ] Script ejecutado: python3 migracion_databasejp.py <token>
- [ ] Verificar que empleados importados
- [ ] Verificar que candidatos importados CON FOTOS
- [ ] Evaluar candidatos en la app
- [ ] Aprobar candidatos → Crear NYUUSHA

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
**Estado**: Listo para usar ✅
