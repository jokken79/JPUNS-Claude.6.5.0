# 入社連絡票 (Nyuusha Renraku Hyou) - Flujo Completo

## 📋 ¿Qué es la 入社連絡票?

La **入社連絡票** (Nyuusha Renraku Hyou = "Formulario de Notificación de Nueva Entrada") es un documento/formulario crítico en el sistema de recursos humanos japonés que registra formalmente la contratación de un nuevo empleado.

**En JokkenClaude-App**: Este proceso está completamente automatizado en 3 pasos:
1. **Auto-creación** cuando el candidato es aprobado
2. **Llenado de datos** por el administrador
3. **Aprobación final** que crea el registro en empleados

---

## 🔄 PASO 1: Auto-creación de la 入社連絡票 (Automático)

### ¿Cuándo sucede?
Cuando un candidato es **aprobado tras una entrevista exitosa**.

### ¿Qué pasa?
El sistema crea automáticamente un registro REQUEST con:
- **type**: NYUUSHA
- **status**: PENDING (esperando completar datos)
- **candidate_id**: ID del candidato aprobado
- **employee_data**: JSON vacío (se llenará en paso 2)

### Código que lo hace (backend/app/api/candidates.py, líneas 629-649)

```python
# AUTO-CREATE 入社連絡票 (New Hire Notification Form)
existing_nyuusha = db.query(RequestModel).filter(
    RequestModel.candidate_id == candidate.id,
    RequestModel.request_type == RequestType.NYUUSHA
).first()

if not existing_nyuusha:
    nyuusha_request = RequestModel(
        candidate_id=candidate.id,
        hakenmoto_id=None,              # ← Se generará en Paso 3
        request_type=RequestType.NYUUSHA,
        status=RequestStatus.PENDING,   # ← Esperando Paso 2
        start_date=date.today(),
        end_date=date.today(),
        reason=f"新規採用: {candidate.full_name_kanji or candidate.full_name_roman}",
        notes=evaluation.notes if hasattr(evaluation, 'notes') and evaluation.notes else None,
        employee_data={}                # ← Vacío, se completa en Paso 2
    )
    db.add(nyuusha_request)
    db.commit()
```

### En la BD
**Tabla: `requests`**
```
ID | candidate_id | request_type | status  | employee_data | hakenmoto_id | approved_at
---|---|---|---|---|---|---
42 | 15 | NYUUSHA | PENDING | {} | NULL | NULL
```

**Tabla: `candidates`**
```
ID | full_name_kanji | status    | rirekisho_id
---|---|---|---
15 | 山田太郎 | approved | 102
```

---

## 📝 PASO 2: Llenado de Datos de Empleado (Administrador)

### ¿Quién lo hace?
Un **administrador HR** (rol: TANTOSHA - 担当者) completa el formulario en la interfaz web.

### ¿Dónde se ve?
En el panel de **Solicitudes Pendientes** → Seleccionar solicitud NYUUSHA → Llenar formulario:

```
┌────────────────────────────────────────────┐
│  Formulario: 入社連絡票 (PENDING)           │
├────────────────────────────────────────────┤
│                                            │
│  Información del Candidato: 山田太郎        │
│  Fecha: 2025-11-22                         │
│                                            │
│  ─── DATOS DE EMPLEO ───                   │
│                                            │
│  Fábrica/Planta: [Dropdown Factories ▼]   │
│    → FUKUOKA_PLANT                         │
│                                            │
│  Fecha de Entrada: [2025-12-01]           │
│                                            │
│  Posición: [Input]                         │
│    → Operario de Producción                │
│                                            │
│  Tipo de Contrato: [Dropdown ▼]           │
│    → Tiempo Indefinido                     │
│                                            │
│  Salario Base (¥): [Input]                 │
│    → 280000                                │
│                                            │
│  Horas Estándar/Día: [Input]              │
│    → 8.5                                   │
│                                            │
│  Número de Cuenta Bancaria: [Input]       │
│    → 1234567890                            │
│                                            │
│  Apartamento Asignado: [Dropdown ▼]       │
│    → APT-001 (Fukuoka)                     │
│                                            │
│  Contacto de Emergencia: [Input]          │
│    → 090-1234-5678                         │
│                                            │
│  [Guardar]  [Cancelar]                     │
│                                            │
└────────────────────────────────────────────┘
```

### ¿Qué datos se guardan?

El sistema hace un **PUT** a `/api/requests/{request_id}/employee-data` con:

```json
{
  "factory_id": "FUKUOKA_PLANT",
  "hire_date": "2025-12-01",
  "position": "Operario de Producción",
  "contract_type": "REGULAR",
  "jikyu": 280000,
  "teiji_hours": 8.5,
  "bank_name": "Mizuho Bank",
  "bank_account": "1234567890",
  "apartment_id": 5,
  "emergency_contact_name": "山田花子",
  "emergency_contact_phone": "090-1234-5678",
  "hakensaki_shain_id": "HAK-001"
}
```

### En la BD (Ahora el `employee_data` tiene contenido)

**Tabla: `requests`**
```sql
UPDATE requests
SET employee_data = '{
  "factory_id": "FUKUOKA_PLANT",
  "hire_date": "2025-12-01",
  "position": "Operario de Producción",
  ...
}'
WHERE id = 42 AND status = 'PENDING';
```

El estado sigue siendo **PENDING** hasta Paso 3.

### Código Backend (backend/app/api/requests.py, líneas 312-431)

```python
@router.put("/{request_id}/employee-data")
async def save_employee_data(
    request_id: int,
    employee_data: dict,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Guarda los datos de empleado para una solicitud NYUUSHA

    Paso 2 del flujo 入社連絡票
    """
    # Validar que es una solicitud NYUUSHA
    request = db.query(RequestModel).filter(
        RequestModel.id == request_id,
        RequestModel.request_type == RequestType.NYUUSHA,
        RequestModel.status == RequestStatus.PENDING
    ).first()

    if not request:
        raise HTTPException(status_code=404, detail="NYUUSHA request not found")

    # Actualizar employee_data JSON
    request.employee_data = employee_data
    db.commit()

    return {"status": "employee_data_saved", "request_id": request_id}
```

---

## ✅ PASO 3: Aprobación Final (Administrador)

### ¿Cuándo?
Cuando el administrador verifica que todos los datos están completos y correctos.

### ¿Qué pasa?
El sistema **crea automáticamente** un nuevo registro en la tabla `EMPLOYEES` copiando:
1. Todos los datos del CANDIDATO
2. Los datos de empleado del formulario (factory, hire_date, position, etc.)

### Flujo Detallado

#### 3a) Admin hace clic en "Aprobar"
```
┌────────────────────────────────────────────┐
│  Solicitud NYUUSHA ID: 42                   │
│  Estado: PENDING                            │
│  Candidato: 山田太郎                         │
│  Datos Completados: ✓                       │
│                                             │
│  [Rechazar]  [← APROBAR →]                  │
│                                             │
└────────────────────────────────────────────┘
```

#### 3b) El sistema hace un POST a `/api/requests/{id}/approve-nyuusha`

```json
POST /api/requests/42/approve-nyuusha
```

#### 3c) Backend ejecuta el código (líneas 523-750):

```python
@router.post("/{request_id}/approve-nyuusha")
async def approve_nyuusha_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    PASO 3: Aprueba la 入社連絡票 y CREA el registro de empleado
    """

    # 1. Obtener la solicitud NYUUSHA
    request = db.query(RequestModel).filter(
        RequestModel.id == request_id,
        RequestModel.request_type == RequestType.NYUUSHA,
        RequestModel.status == RequestStatus.PENDING
    ).first()

    if not request:
        raise HTTPException(status_code=404)

    # 2. Obtener el candidato
    candidate = db.query(Candidate).filter(
        Candidate.id == request.candidate_id
    ).first()

    if not candidate:
        raise HTTPException(status_code=404)

    # 3. Validar que employee_data fue completado
    emp_data = request.employee_data or {}
    if not emp_data.get("factory_id") or not emp_data.get("hire_date"):
        raise HTTPException(
            status_code=400,
            detail="Employee data incomplete"
        )

    # 4. Generar nuevo hakenmoto_id (ID del empleado)
    last_employee = db.query(Employee).order_by(
        Employee.hakenmoto_id.desc()
    ).first()

    new_hakenmoto_id = (last_employee.hakenmoto_id or 0) + 1

    # 5. CREAR NUEVO EMPLEADO
    new_employee = Employee(
        # === DATOS COPIADOS DEL CANDIDATO ===
        hakenmoto_id=new_hakenmoto_id,
        rirekisho_id=candidate.rirekisho_id,

        # Información personal
        full_name_roman=candidate.full_name_roman,
        full_name_kanji=candidate.full_name_kanji,
        full_name_kana=candidate.full_name_kana,
        date_of_birth=candidate.date_of_birth,
        gender=candidate.gender,
        nationality=candidate.nationality,
        email=candidate.email,
        phone=candidate.phone,
        address=candidate.address,
        photo_data_url=candidate.photo_data_url,

        # Documentos de residencia
        passport_number=candidate.passport_number,
        residence_card_number=candidate.residence_card_number,
        residence_status=candidate.residence_status,
        residence_expiry=candidate.residence_expiry,

        # Información familiar
        marital_status=candidate.marital_status,

        # === DATOS DEL FORMULARIO NYUUSHA ===
        factory_id=emp_data.get("factory_id"),
        hire_date=emp_data.get("hire_date"),
        jikyu=emp_data.get("jikyu"),
        position=emp_data.get("position"),
        contract_type=emp_data.get("contract_type"),
        teiji_hours=emp_data.get("teiji_hours"),
        hakensaki_shain_id=emp_data.get("hakensaki_shain_id"),
        apartment_id=emp_data.get("apartment_id"),

        # Información bancaria
        bank_name=emp_data.get("bank_name"),
        bank_account=emp_data.get("bank_account"),

        # Contacto de emergencia
        emergency_contact_name=emp_data.get("emergency_contact_name"),
        emergency_contact_phone=emp_data.get("emergency_contact_phone"),

        # Estado
        status="active",
        created_at=datetime.now(),
        updated_at=datetime.now()
    )

    db.add(new_employee)

    # 6. ACTUALIZAR CANDIDATO
    candidate.status = "hired"  # ← Candidato ya está contratado

    # 7. ACTUALIZAR SOLICITUD
    request.hakenmoto_id = new_hakenmoto_id
    request.status = RequestStatus.COMPLETED  # ← Solicitud completada
    request.approved_by = current_user.id
    request.approved_at = datetime.now()

    # 8. GUARDAR TODOS LOS CAMBIOS
    db.commit()
    db.refresh(new_employee)

    # 9. RETORNAR CONFIRMACIÓN
    return {
        "status": "success",
        "message": f"Empleado {new_employee.full_name_kanji} creado exitosamente",
        "employee_id": new_employee.hakenmoto_id,
        "employee_data": new_employee
    }
```

---

## 📊 Resumen Visual del Flujo Completo

```
CANDIDATO APROBADO
        │
        ↓
┌─────────────────────────────────────────────┐
│ PASO 1: AUTO-CREAR 入社連絡票                │
│                                             │
│ • Request.type = NYUUSHA                    │
│ • Request.status = PENDING                  │
│ • Request.employee_data = {} (vacío)        │
│ • candidate_id = 15                         │
│                                             │
│ ⏱️ Automático - Instantáneo                  │
└─────────────────────────────────────────────┘
        │
        ↓
┌─────────────────────────────────────────────┐
│ PASO 2: LLENAR DATOS DE EMPLEADO            │
│                                             │
│ Admin completa formulario:                  │
│ • Factory: FUKUOKA_PLANT                    │
│ • Hire Date: 2025-12-01                     │
│ • Position: Operario                        │
│ • Salary: ¥280,000                          │
│ • Bank Account: 1234567890                  │
│ • Apartment: APT-001                        │
│                                             │
│ Request.status SIGUE siendo PENDING          │
│                                             │
│ ⏱️ Manual - Unos minutos                     │
└─────────────────────────────────────────────┘
        │
        ↓
┌─────────────────────────────────────────────┐
│ PASO 3: APROBAR Y CREAR EMPLEADO            │
│                                             │
│ Admin hace clic "Aprobar"                   │
│                                             │
│ Sistema automáticamente:                    │
│ ✓ Crea registro en tabla EMPLOYEES          │
│ ✓ Copia 40+ campos del CANDIDATO            │
│ ✓ Agrega datos del formulario               │
│ ✓ Genera hakenmoto_id (ID empleado)         │
│ ✓ Marca Candidato como HIRED                │
│ ✓ Marca Request como COMPLETED              │
│                                             │
│ ⏱️ Automático - Instantáneo                  │
└─────────────────────────────────────────────┘
        │
        ↓
EMPLEADO REGISTRADO EN LA BD ✓
(Ahora aparece en tabla EMPLOYEES)
```

---

## 🗂️ Cambios en la Base de Datos

### ANTES (Solo después de Paso 1)

**Tabla: `requests`**
| id | candidate_id | request_type | status | employee_data |
|-|-|-|-|-|
| 42 | 15 | NYUUSHA | PENDING | `{}` |

**Tabla: `candidates`**
| id | full_name_kanji | status | rirekisho_id |
|-|-|-|-|
| 15 | 山田太郎 | approved | 102 |

**Tabla: `employees`**
| (No hay cambio aún) |

---

### DESPUÉS (Después de Paso 3)

**Tabla: `requests`**
| id | candidate_id | request_type | status | employee_data | hakenmoto_id | approved_at |
|-|-|-|-|-|-|-|
| 42 | 15 | NYUUSHA | COMPLETED | `{factory_id, hire_date, ...}` | 156 | 2025-11-22 14:30 |

**Tabla: `candidates`**
| id | full_name_kanji | status | rirekisho_id |
|-|-|-|-|
| 15 | 山田太郎 | **hired** | 102 |

**Tabla: `employees`** ← **¡NUEVO REGISTRO!**
| hakenmoto_id | full_name_kanji | factory_id | hire_date | position | status | created_at |
|-|-|-|-|-|-|-|
| **156** | 山田太郎 | FUKUOKA_PLANT | 2025-12-01 | Operario | active | 2025-11-22 14:30 |

---

## 🔑 Campos Copiados (Candidate → Employee)

| Campo | Origen | Destino |
|-------|--------|---------|
| Nombre (Kanji) | candidates.full_name_kanji | employees.full_name_kanji |
| Nombre (Romaji) | candidates.full_name_roman | employees.full_name_roman |
| Nombre (Kana) | candidates.full_name_kana | employees.full_name_kana |
| Fecha Nacimiento | candidates.date_of_birth | employees.date_of_birth |
| Género | candidates.gender | employees.gender |
| Nacionalidad | candidates.nationality | employees.nationality |
| Email | candidates.email | employees.email |
| Teléfono | candidates.phone | employees.phone |
| Dirección | candidates.address | employees.address |
| Foto | candidates.photo_data_url | employees.photo_data_url |
| Pasaporte | candidates.passport_number | employees.passport_number |
| Tarjeta Residencia | candidates.residence_card_number | employees.residence_card_number |
| Estado Residencia | candidates.residence_status | employees.residence_status |

**+**

| Campo | Origen (Formulario) | Destino |
|-------|-----|---------|
| Factory | employee_data.factory_id | employees.factory_id |
| Fecha Entrada | employee_data.hire_date | employees.hire_date |
| Posición | employee_data.position | employees.position |
| Salario | employee_data.jikyu | employees.jikyu |
| Tipo Contrato | employee_data.contract_type | employees.contract_type |
| Cuenta Bancaria | employee_data.bank_account | employees.bank_account |
| Apartamento | employee_data.apartment_id | employees.apartment_id |

---

## 💾 Consultas SQL Útiles

### Ver solicitudes NYUUSHA pendientes
```sql
SELECT
    r.id,
    c.full_name_kanji,
    r.status,
    r.employee_data
FROM requests r
JOIN candidates c ON r.candidate_id = c.id
WHERE r.request_type = 'nyuusha'
AND r.status = 'pending'
ORDER BY r.created_at DESC;
```

### Ver el flujo completo de un candidato
```sql
SELECT
    c.id as candidate_id,
    c.full_name_kanji,
    c.status as candidate_status,
    r.request_type,
    r.status as request_status,
    e.hakenmoto_id,
    e.status as employee_status
FROM candidates c
LEFT JOIN requests r ON c.id = r.candidate_id
LEFT JOIN employees e ON r.hakenmoto_id = e.hakenmoto_id
WHERE c.id = 15;
```

**Resultado (Paso 1):**
```
candidate_id | full_name_kanji | candidate_status | request_type | request_status | hakenmoto_id | employee_status
15 | 山田太郎 | approved | NYUUSHA | PENDING | NULL | NULL
```

**Resultado (Paso 3 - Después de aprobación):**
```
candidate_id | full_name_kanji | candidate_status | request_type | request_status | hakenmoto_id | employee_status
15 | 山田太郎 | hired | NYUUSHA | COMPLETED | 156 | active
```

### Ver historial de entrada de un empleado
```sql
SELECT
    e.hakenmoto_id,
    e.full_name_kanji,
    e.hire_date,
    r.created_at as request_created_at,
    r.approved_at as request_approved_at
FROM employees e
JOIN requests r ON r.hakenmoto_id = e.hakenmoto_id
WHERE r.request_type = 'nyuusha'
ORDER BY r.approved_at DESC;
```

---

## 🔗 Endpoints Relacionados

### Crear/Actualizar NYUUSHA
```
PUT /api/requests/{request_id}/employee-data
Content-Type: application/json

{
  "factory_id": "FUKUOKA_PLANT",
  "hire_date": "2025-12-01",
  "position": "Operario",
  "jikyu": 280000,
  ...
}
```

### Aprobar NYUUSHA
```
POST /api/requests/{request_id}/approve-nyuusha

Response:
{
  "status": "success",
  "employee_id": 156,
  "message": "Empleado 山田太郎 creado exitosamente"
}
```

### Ver solicitudes pendientes
```
GET /api/requests?status=pending&type=nyuusha
```

---

## ✨ Resumen: Respuesta a Tu Pregunta

**Tu pregunta:** "Pero después que es candidato es aceptado. No hay algún formulario como 入社連続票？ después que en ese formulario se colocan los datos restantes etc. se guarda e imprime. Y de ahí se aprueba la entrada. Ahí debería registrase en la tabla de empleados no?"

**Respuesta:** ✅ **¡SÍ! Exactamente eso es lo que pasa:**

1. ✅ **Candidato aceptado** → Se auto-crea automáticamente la 入社連絡票
2. ✅ **Formulario** → Existe en la interfaz, admin completa: factory, hire_date, position, salary, bank, apartment, etc.
3. ✅ **Se guarda** → Los datos se guardan en la columna JSONB `employee_data` de la tabla `requests`
4. ✅ **Se aprueba** → Admin hace clic "Aprobar"
5. ✅ **Se registra en empleados** → El sistema crea automáticamente un nuevo registro en tabla `EMPLOYEES` con todos los datos del candidato + datos del formulario

**La conexión:**
- Un CANDIDATO se convierte en EMPLEADO cuando su 入社連絡票 es aprobada
- El `hakenmoto_id` (ID del empleado) se genera automáticamente en el Paso 3
- El candidato cambia de status: `approved` → `hired`
- La solicitud cambia de status: `pending` → `completed`

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
**Estado**: Completamente Documentado ✅
