# 📋 Importar Candidatos con Fotos - Guía Completa

## 🎯 ¿Qué es la Importación de Candidatos?

El sistema te permite importar candidatos de dos formas:

1. **Forma Manual**: Completar formulario 履歴書 (Rirekisho) con foto
2. **Forma Automática**: Cargar documento (foto, PDF) y OCR extrae datos automáticamente

---

## ✨ OPCIÓN 1: Método Manual - Rirekisho (履歴書) Form

### ¿Qué es Rirekisho?

**履歴書** (Rirekisho) = "Formulario de Historial Laboral" (currículo/CV japonés)

Es el documento estándar para solicitar empleo en Japón. Contiene:
- Datos personales
- Educación
- Experiencia laboral
- Foto
- Información de contacto

### 📝 Paso 1: Acceder al Formulario

```
Frontend: http://localhost:3000
↓
Menu: Reclutamiento → Candidatos
↓
Botón: "Nuevo Candidato" o "Cargar Rirekisho"
```

### 📸 Paso 2: Cargar Foto

El formulario tiene un campo para **FOTO**:

```
┌─────────────────────────────┐
│ Foto del Candidato          │
│                             │
│ [Click para seleccionar]    │
│ o Arrastra una imagen       │
│                             │
│ (Máximo 10 MB)              │
│ (Soporta: JPG, PNG, WebP)   │
│                             │
└─────────────────────────────┘
```

**Lo que pasa automáticamente:**
- ✅ Valida tamaño (máx 10 MB)
- ✅ Valida formato (JPG, PNG, WebP)
- ✅ **Comprime automáticamente** (800x1000 px, quality 85)
- ✅ Guarda en servidor

### 📋 Paso 3: Llenar Datos del Formulario

```
Nombre Kanji (漢字):        山田太郎
Nombre Kana (ひらがな):     やまだたろう
Nombre Romaji:             Yamada Taro

Fecha de Nacimiento:       1990-05-15
Género:                   Masculino
Nacionalidad:             Japonés
Email:                    yamada.taro@example.com
Teléfono:                 090-1234-5678
Dirección:                福岡県福岡市中央区

Educación:
- Primaria:  XXXX-XXXX
- Secundaria: XXXX-XXXX
- Universidad: XXXX-XXXX

Experiencia Laboral:
- Empresa 1:     XXXX-XXXX (Posición)
- Empresa 2:     XXXX-XXXX (Posición)

Documentos:
- Pasaporte:     ABC1234567
- Tarjeta Residencia: XXXX-XXXX
- Estado Residencia: Long-term resident
```

### ✅ Paso 4: Guardar

```
Botón: [Guardar Rirekisho]
↓
Sistema crea automáticamente:
- Candidato record
- Asigna applicant_id único
- Asigna rirekisho_id único
- Guarda foto comprimida
- Valida todos los datos
↓
Candidato aparece en lista
```

### 📊 Resultado en la BD

**Tabla: candidates**
```
id | applicant_id | rirekisho_id | full_name_kanji | full_name_kana | photo_data_url | status
---|---|---|---|---|---|---
1 | APP-001 | RIR-001 | 山田太郎 | やまだたろう | data:image/jpeg;base64... | registered
```

**Tabla: candidate_forms**
```
id | candidate_id | rirekisho_id | form_data (JSON) | photo_data_url
---|---|---|---|---
1 | 1 | RIR-001 | {campos del formulario} | data:image/jpeg;base64...
```

---

## 🤖 OPCIÓN 2: Método Automático - OCR (Reconocimiento Óptico)

### ¿Qué es OCR?

**OCR** = Optical Character Recognition

El sistema **lee automáticamente** documentos:
- 📷 Foto de documento de identidad
- 📄 PDF de currículo
- 📸 Escaneo de 履歴書
- 🆔 Tarjeta de residencia (在留カード)

Y **extrae datos automáticamente**:
- Nombre (Kanji, Kana)
- Fecha de nacimiento
- Nacionalidad
- Dirección
- Teléfono
- Etc.

### 📋 Soporta 3 Tipos de Documentos

| Tipo | Código | Qué Extrae |
|------|--------|-----------|
| **Rirekisho** | rirekisho | 履歴書 (Resume) - Datos educación/experiencia |
| **Tarjeta Residencia** | zairyu_card | 在留カード - Datos personales/residencia |
| **Licencia de Conducir** | license | 免許証 - Datos personales |

### 🚀 Paso 1: Usar Endpoint de OCR

```
POST /api/candidates/ocr/process
Content-Type: multipart/form-data

- file: [tu-documento.jpg]
- document_type: rirekisho | zairyu_card | license
```

**En curl:**
```bash
curl -X POST "http://localhost:8000/api/candidates/ocr/process" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@path/to/documento.jpg" \
  -F "document_type=rirekisho"
```

**En Python:**
```python
import requests

url = "http://localhost:8000/api/candidates/ocr/process"
files = {
    'file': open('rirekisho.jpg', 'rb'),
    'document_type': (None, 'rirekisho')
}
headers = {'Authorization': f'Bearer {token}'}

response = requests.post(url, files=files, headers=headers)
data = response.json()
print(data)
```

### 📊 Paso 2: Ver Resultado OCR

**Respuesta del servidor:**
```json
{
  "status": "success",
  "data": {
    "success": true,
    "data": {
      "name_kanji": "山田太郎",
      "name_kana": "やまだたろう",
      "birthday": "1990-05-15",
      "gender": "男性",
      "nationality": "日本",
      "address": "福岡県福岡市中央区",
      "phone": "090-1234-5678",
      "email": "yamada@example.com",
      "raw_text": "[Texto extraído completo del documento]",
      "document_type": "rirekisho"
    },
    "message": "Document processed successfully"
  }
}
```

### ✅ Paso 3: Crear Candidato desde OCR

Una vez que OCR extrae los datos, puedes **crear candidato automáticamente**:

```bash
POST /api/candidates/rirekisho/form
Content-Type: application/json

{
  "form_data": {
    "full_name_kanji": "山田太郎",
    "full_name_kana": "やまだたろう",
    "date_of_birth": "1990-05-15",
    "gender": "male",
    "nationality": "Japanese",
    "email": "yamada@example.com",
    "phone": "090-1234-5678",
    "address": "福岡県福岡市中央区"
  },
  "photo_data_url": "data:image/jpeg;base64,/9j/4AAQSkZJRg...",
  "rirekisho_id": "RIR-001"
}
```

**Respuesta:**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "candidate_id": 1,
    "rirekisho_id": "RIR-001",
    "applicant_id": "APP-001",
    "form_data": {...},
    "photo_data_url": "data:image/jpeg;base64,..."
  }
}
```

---

## 📸 Detalles Sobre Fotos

### Validación Automática de Foto

Cuando subes una foto, el sistema:

```
1. Valida tipo (JPG, PNG, WebP)
   ↓
2. Valida tamaño (máx 10 MB)
   ↓
3. Verifica que sea imagen válida (no corrupta)
   ↓
4. Comprime automáticamente:
   - Redimensiona a máx 800x1000 px
   - Reduce quality a 85%
   - Guarda como Base64
   ↓
5. Registra info de foto original y comprimida en logs
```

### Información de la Foto Registrada

El sistema guarda (en logs):
```
Original photo: 3000x4000 pixels, 8.50MB (JPEG)
Compressed photo: 750x1000 pixels, 0.85MB
```

### Dónde se Guarda la Foto

```
En la BD (tabla candidates):
photo_data_url = "data:image/jpeg;base64,/9j/4AAQSkZJRgABA..."

En servidor:
/uploads/candidates/{candidate_id}/foto.jpg
```

---

## 🔄 Flujo Completo: De Documento a Candidato Registrado

```
Tu tienes documento (Rirekisho, Foto de ID, etc.)
    ↓
Opción A: Manual
├─ Llenar formulario manualmente
├─ Subir foto
└─ Guardar → Candidato creado

Opción B: Automático (OCR)
├─ Subir documento a /ocr/process
├─ Sistema lee documento
├─ Extrae datos automáticamente
├─ Retorna datos extraídos
├─ Subir resultado a /rirekisho/form
└─ Candidato creado
```

---

## 📋 Tabla de Endpoints para Importar Candidatos

| Operación | Endpoint | Método | Parámetros |
|-----------|----------|--------|-----------|
| Procesar OCR | `/api/candidates/ocr/process` | POST | file, document_type |
| Crear candidato manual | `/api/candidates/rirekisho/form` | POST | form_data, photo_data_url |
| Subir documento individual | `/api/candidates/{id}/upload` | POST | file, document_type |
| Ver candidatos | `/api/candidates` | GET | skip, limit, status |
| Ver candidato | `/api/candidates/{id}` | GET | - |
| Evaluar candidato | `/api/candidates/{id}/evaluate` | POST | evaluation_data |
| Aprobar candidato | `/api/candidates/{id}/approve` | POST | - |

---

## 🛠️ Tipos de Documentos Soportados

### Formatos de Archivo

```
JPG   ✅
JPEG  ✅
PNG   ✅
PDF   ✅
WebP  ✅
```

### Documentos con OCR Automático

```
履歴書 (Rirekisho)
├─ Extrae: Nombre, fecha nacimiento, educación, experiencia
└─ Campos: full_name_kanji, full_name_kana, date_of_birth, etc.

在留カード (Zairyu Card - Tarjeta Residencia)
├─ Extrae: Nombre, nacionalidad, estado residencia, dirección
└─ Campos: nationality, residence_status, address

免許証 (Driver's License)
├─ Extrae: Nombre, fecha nacimiento, dirección, validez
└─ Campos: full_name_kanji, date_of_birth, address
```

---

## 💡 Casos de Uso

### Caso 1: Importar UN Candidato Rápidamente

```bash
# 1. Tomar foto del Rirekisho
# 2. Subir a OCR
curl -X POST "http://localhost:8000/api/candidates/ocr/process" \
  -F "file=@rirekisho.jpg" \
  -F "document_type=rirekisho"

# 3. Copiar respuesta
# 4. Crear candidato con datos extraídos
curl -X POST "http://localhost:8000/api/candidates/rirekisho/form" \
  -H "Content-Type: application/json" \
  -d '{
    "form_data": {...datos_de_ocr...},
    "photo_data_url": "data:image/jpeg;base64,..."
  }'

# ¡Listo! Candidato importado
```

### Caso 2: Importar Múltiples Candidatos (Batch)

```bash
# Script para procesar 10 documentos automáticamente
for archivo in *.jpg; do
  echo "Procesando $archivo..."

  # OCR
  ocr_result=$(curl -s -X POST "http://localhost:8000/api/candidates/ocr/process" \
    -F "file=@$archivo" \
    -F "document_type=rirekisho")

  # Crear candidato
  curl -s -X POST "http://localhost:8000/api/candidates/rirekisho/form" \
    -H "Content-Type: application/json" \
    -d "{...}"

  echo "✓ $archivo importado"
done
```

### Caso 3: Verificar Foto Después de Importación

```bash
GET /api/candidates/{candidate_id}

Respuesta incluye:
{
  "id": 1,
  "photo_data_url": "data:image/jpeg;base64,/9j/4AAQSkZJRg...",
  "full_name_kanji": "山田太郎"
}
```

---

## 🔒 Validaciones y Límites

| Validación | Límite | Nota |
|-----------|--------|------|
| Tamaño máximo de foto | 10 MB | Antes de compresión |
| Tamaño comprimido | ~1 MB | Típicamente después |
| Dimensiones máximas | 800x1000 px | Después de compresión |
| Quality JPEG | 85% | Buena calidad, pequeño tamaño |
| Rate limit OCR | 10/minuto | Operación costosa |
| Rate limit candidato | 30/minuto | Operación normal |

---

## 🐛 Troubleshooting

### ❌ ERROR: "File type not allowed"

**Solución:**
```
Soportados: JPG, JPEG, PNG, WebP, PDF
Verifica que tu archivo tiene extensión correcta
```

### ❌ ERROR: "File size exceeds maximum"

**Solución:**
```
Máximo 10 MB
Intenta comprimir la imagen:
- Reducir resolución
- Usar menor quality
- Convertir a PNG (más eficiente)
```

### ❌ ERROR: "Invalid or corrupted image file"

**Solución:**
```
La imagen está dañada
Intenta:
1. Capturar nuevamente
2. Escaneador en mejor resolución
3. Convertir a JPG si está en otro formato
```

### ❌ ERROR: "OCR processing error"

**Solución:**
```
Documento muy borroso o pequeño
Intenta:
1. Mejor iluminación
2. Mayor resolución
3. Documento centrado en foto
4. Sin sombras o reflejos
```

---

## 📊 Ejemplo Completo: Python

```python
import requests
from pathlib import Path

# Config
API_URL = "http://localhost:8000/api"
TOKEN = "your_token_here"
headers = {"Authorization": f"Bearer {TOKEN}"}

# Paso 1: Procesar documento con OCR
def process_with_ocr(file_path: str, doc_type: str):
    with open(file_path, 'rb') as f:
        files = {
            'file': f,
            'document_type': (None, doc_type)
        }
        response = requests.post(
            f"{API_URL}/candidates/ocr/process",
            files=files,
            headers=headers
        )
    return response.json()

# Paso 2: Crear candidato desde OCR
def create_candidate_from_ocr(ocr_data: dict):
    payload = {
        "form_data": ocr_data['data'],
        "photo_data_url": ocr_data.get('photo_base64')
    }
    response = requests.post(
        f"{API_URL}/candidates/rirekisho/form",
        json=payload,
        headers=headers
    )
    return response.json()

# Uso
if __name__ == "__main__":
    # Procesar documento
    print("Procesando documento con OCR...")
    ocr_result = process_with_ocr("rirekisho.jpg", "rirekisho")

    if ocr_result['status'] == 'success':
        print(f"OCR exitoso: {ocr_result['data']['data']['name_kanji']}")

        # Crear candidato
        print("Creando candidato...")
        candidate = create_candidate_from_ocr(ocr_result['data'])

        if candidate['status'] == 'success':
            candidate_id = candidate['data']['candidate_id']
            print(f"✓ Candidato creado: {candidate_id}")
        else:
            print(f"✗ Error creando candidato: {candidate['detail']}")
    else:
        print(f"✗ Error OCR: {ocr_result['detail']}")
```

---

## ✨ Resumen: Tu Pregunta Respondida

**Tu pregunta:** "¿Y la función de importar candidatos con sus fotos?"

**Respuesta:** ✅ **¡SÍ! El sistema lo hace completamente:**

### Forma 1: Manual
1. Llenar formulario Rirekisho
2. Subir foto (se comprime automáticamente)
3. Guardar → Candidato creado

### Forma 2: Automática (OCR)
1. Tomar foto de documento (Rirekisho, ID, etc.)
2. Subir a `/api/candidates/ocr/process`
3. Sistema lee automáticamente y extrae datos
4. Crear candidato desde datos extraídos

### Características de Fotos
- ✅ Validación automática (tipo, tamaño)
- ✅ Compresión automática (800x1000, quality 85)
- ✅ Almacenamiento en BD como Base64
- ✅ Logs de foto original vs comprimida
- ✅ Máximo 10 MB

### OCR Soporta
- 📄 Rirekisho (履歴書)
- 🆔 Zairyu Card (在留カード)
- 🚗 Driver's License (免許証)
- 📷 Formatos: JPG, PNG, PDF, WebP

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
**Estado**: Completamente Documentado ✅
