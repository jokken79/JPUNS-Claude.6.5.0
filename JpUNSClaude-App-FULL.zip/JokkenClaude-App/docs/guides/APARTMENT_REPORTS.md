# 📊 Reportes de Apartamentos - Guía Completa

## ¿Qué es un Reporte de Apartamentos?

Un **reporte de apartamentos** es un análisis completo que muestra:
- **Quién vive en cada apartamento** (ocupantes actuales)
- **Cuánto tienen que pagar** (renta + cargos adicionales)
- **Período de ocupación** (del 1 al 30/31 del mes)
- **Estado de pagos** (pendiente, procesado, pagado)

---

## 🏢 PARTE 1: Ver Quién Vive en Cada Apartamento (Ocupación Actual)

### Endpoint: Asignaciones Activas

```
GET /api/apartments/assignments/active
```

Este endpoint te muestra **AHORA MISMO** quién vive en qué apartamento.

### Ejemplo de Respuesta

```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "apartment": {
        "id": 5,
        "code": "APT-001",
        "address": "福岡市中央区",
        "room_type": "single",
        "monthly_rent": 45000
      },
      "employee": {
        "hakenmoto_id": 156,
        "full_name_kanji": "山田太郎",
        "full_name_kana": "やまだたろう",
        "email": "yamada.taro@example.com"
      },
      "start_date": "2025-12-01",
      "end_date": null,  // ← null = sigue viviendo
      "status": "active",
      "monthly_rent": 45000,
      "created_at": "2025-12-01"
    },
    {
      "id": 2,
      "apartment": {
        "id": 6,
        "code": "APT-002",
        "address": "福岡市中央区",
        "room_type": "double",
        "monthly_rent": 55000
      },
      "employee": {
        "hakenmoto_id": 157,
        "full_name_kanji": "鈴木花子",
        "full_name_kana": "すずきはなこ",
        "email": "suzuki.hanako@example.com"
      },
      "start_date": "2025-11-15",
      "end_date": null,
      "status": "active",
      "monthly_rent": 55000,
      "created_at": "2025-11-15"
    }
  ]
}
```

### Cómo Usarlo

**En curl:**
```bash
curl -X GET "http://localhost:8000/api/apartments/assignments/active" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**En la UI (Frontend):**
1. Ve a **Departamento** → **Apartamentos** → **Estado de Ocupación**
2. Verás una tabla con todos los apartamentos ocupados

---

## 💰 PARTE 2: Deducciones Mensuales (Quién Paga Cuánto)

### Paso 1: GENERAR Deducciones del Mes

Primero, el sistema calcula automáticamente cuánto debe pagar cada empleado por su apartamento en el mes.

#### Endpoint: Generar Deducciones

```
POST /api/apartments/deductions/generate?year=2025&month=12
```

**Parámetros:**
- `year`: Año (ej: 2025)
- `month`: Mes (1-12) (ej: 12 = Diciembre)

**Lo que hace:**
1. Busca todos los empleados que viven en apartamentos en ese mes
2. Para cada empleado:
   - Calcula **días ocupados** en el mes
   - Calcula **renta prorrateada** (si empezó a mitad de mes)
   - Suma **cargos adicionales** (limpieza, reparaciones, etc.)
   - Genera una **deducción** con el total
3. Guarda todo en la BD

**En curl:**
```bash
curl -X POST "http://localhost:8000/api/apartments/deductions/generate?year=2025&month=12" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Ejemplo de respuesta:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1001,
      "assignment_id": 1,
      "employee_id": 156,
      "apartment_id": 5,
      "year": 2025,
      "month": 12,
      "base_rent": 45000,
      "additional_charges": 5000,
      "total_amount": 50000,
      "days_occupied": 31,
      "status": "pending",
      "notes": "Diciembre completo - Deducción en nómina",
      "created_at": "2025-12-01"
    },
    {
      "id": 1002,
      "assignment_id": 2,
      "employee_id": 157,
      "apartment_id": 6,
      "year": 2025,
      "month": 12,
      "base_rent": 55000,
      "additional_charges": 0,
      "total_amount": 55000,
      "days_occupied": 31,
      "status": "pending",
      "notes": "Diciembre completo",
      "created_at": "2025-12-01"
    }
  ]
}
```

---

### Paso 2: VER Deducciones del Mes

#### Endpoint: Listar Deducciones

```
GET /api/apartments/deductions/{year}/{month}
```

**Parámetros opcionales:**
- `apartment_id`: Filtrar por apartamento específico
- `employee_id`: Filtrar por empleado específico
- `status`: Filtrar por estado (pending, processed, paid, cancelled)

**Ejemplo - Ver TODAS las deducciones de Diciembre 2025:**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/2025/12" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Ejemplo - Ver deducciones PENDIENTES de Diciembre:**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/2025/12?status=pending" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Ejemplo - Ver deducción de un apartamento específico:**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/2025/12?apartment_id=5" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Respuesta:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1001,
      "employee_kanji": "山田太郎",
      "apartment_code": "APT-001",
      "base_rent": 45000,
      "additional_charges": 5000,
      "total_amount": 50000,
      "days_occupied": 31,
      "status": "pending",
      "payment_date": null
    },
    {
      "id": 1002,
      "employee_kanji": "鈴木花子",
      "apartment_code": "APT-002",
      "base_rent": 55000,
      "additional_charges": 0,
      "total_amount": 55000,
      "days_occupied": 31,
      "status": "pending",
      "payment_date": null
    }
  ]
}
```

---

### Paso 3: EXPORTAR Deducciones a Excel

#### Endpoint: Exportar a Excel

```
GET /api/apartments/deductions/export/{year}/{month}
```

**Ejemplo:**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/export/2025/12" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  --output "deducciones_diciembre_2025.xlsx"
```

**El archivo Excel incluye:**

| Columna | Contenido | Ejemplo |
|---------|-----------|---------|
| A | Empleado ID | 156 |
| B | Nombre Kanji | 山田太郎 |
| C | Nombre Kana | やまだたろう |
| D | Apartamento Código | APT-001 |
| E | Apartamento Dirección | 福岡市中央区 |
| F | Renta Base | ¥45,000 |
| G | Cargos Adicionales | ¥5,000 |
| H | Total Deducción | ¥50,000 |
| I | Días Ocupados | 31 |
| J | Fecha Inicio | 2025-12-01 |
| K | Fecha Fin | 2025-12-31 |
| L | Estado | pending |
| M | Notas | Diciembre completo |

---

## 📈 PARTE 3: Reportes Avanzados

### Reporte 1: Ocupación (Quién Vive Dónde)

#### Endpoint: Reporte de Ocupación

```
GET /api/apartments/reports/occupancy
```

**Parámetros opcionales:**
- `prefecture`: Filtrar por prefectura (ej: "福岡県")
- `building_name`: Filtrar por edificio

**Ejemplo:**
```bash
curl -X GET "http://localhost:8000/api/apartments/reports/occupancy" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Respuesta - Estadísticas Completas:**
```json
{
  "status": "success",
  "data": {
    "total_apartments": 150,
    "occupied_apartments": 128,
    "vacant_apartments": 22,
    "occupancy_rate": 85.33,
    "total_capacity": 450,
    "occupied_beds": 385,
    "utilization_rate": 85.56,
    "average_occupancy_per_building": 87.2,
    "breakdown_by_prefecture": {
      "福岡県": {
        "total": 80,
        "occupied": 72,
        "rate": 90.0
      },
      "長崎県": {
        "total": 70,
        "occupied": 56,
        "rate": 80.0
      }
    },
    "breakdown_by_room_type": {
      "single": {
        "total": 100,
        "occupied": 85,
        "rate": 85.0
      },
      "double": {
        "total": 50,
        "occupied": 43,
        "rate": 86.0
      }
    }
  }
}
```

**Usa esto para:**
- Saber tasa de ocupación global
- Identificar apartamentos vacíos
- Análisis por región o tipo de habitación

---

### Reporte 2: Pagos Pendientes (Quién Debe Dinero)

#### Endpoint: Reporte de Adeudos

```
GET /api/apartments/reports/arrears?year=2025&month=12
```

**Parámetros:**
- `year`: Año (ej: 2025)
- `month`: Mes (1-12)

**Ejemplo:**
```bash
curl -X GET "http://localhost:8000/api/apartments/reports/arrears?year=2025&month=12" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Respuesta - Análisis de Cobranza:**
```json
{
  "status": "success",
  "data": {
    "summary": {
      "total_expected": 2450000,
      "total_paid": 1850000,
      "total_pending": 600000,
      "collection_rate": 75.51
    },
    "monthly_trends": [
      {"month": 1, "expected": 2400000, "paid": 2300000, "rate": 95.83},
      {"month": 2, "expected": 2400000, "paid": 2250000, "rate": 93.75},
      {"month": 12, "expected": 2450000, "paid": 1850000, "rate": 75.51}
    ],
    "by_status": {
      "paid": 185,
      "pending": 60,
      "processed": 45
    },
    "top_debtors": [
      {
        "employee_id": 156,
        "name": "山田太郎",
        "amount_pending": 250000,
        "days_overdue": 45
      },
      {
        "employee_id": 202,
        "name": "田中次郎",
        "amount_pending": 180000,
        "days_overdue": 30
      }
    ],
    "by_apartment": [
      {
        "apartment_code": "APT-001",
        "total": 450000,
        "pending": 50000
      }
    ]
  }
}
```

**Usa esto para:**
- Seguimiento de pagos
- Identificar empleados con adeudos
- Reportes de contabilidad
- Calcular tasa de cobranza

---

### Reporte 3: Mantenimiento

#### Endpoint: Reporte de Mantenimiento

```
GET /api/apartments/reports/maintenance?period=6months
```

**Parámetros:**
- `period`: Período (3months, 6months, 1year)
- `charge_type`: Filtrar por tipo (cleaning, repair, deposit, penalty, other)

**Respuesta - Historial de Gastos:**
```json
{
  "status": "success",
  "data": {
    "period": "6months",
    "total_charges": 450000,
    "charge_count": 25,
    "average_per_apartment": 3000,
    "by_type": {
      "cleaning": {
        "count": 10,
        "total": 200000,
        "average": 20000
      },
      "repair": {
        "count": 8,
        "total": 150000,
        "average": 18750
      },
      "deposit": {
        "count": 5,
        "total": 100000
      },
      "other": {
        "count": 2,
        "total": 0
      }
    },
    "monthly_trend": [...]
  }
}
```

---

## 🎯 Workflow Completo: Del 1 al Fin de Mes

### Día 1 del Mes (Inicio)

**1. GENERAR deducciones automáticamente**
```bash
curl -X POST "http://localhost:8000/api/apartments/deductions/generate?year=2025&month=12" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Sistema automáticamente:
- ✅ Calcula quién vive dónde
- ✅ Calcula cuántos días ocupados
- ✅ Calcula renta prorrateada
- ✅ Suma cargos adicionales
- ✅ Crea deducciones (status: pending)

---

### Día 15 del Mes (Control)

**2. VER deducciones generadas**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/2025/12?status=pending" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Verifica:
- ✅ ¿Todas las deducciones están generadas?
- ✅ ¿Los montos son correctos?
- ✅ ¿Hay alguien que no debería estar?

**3. Hacer ajustes si es necesario**
- Agregar cargos adicionales para reparaciones
- Modificar montos si hay cambios de ocupación

---

### Fin de Mes (Procesamiento)

**4. EXPORTAR a Excel para nómina**
```bash
curl -X GET "http://localhost:8000/api/apartments/deductions/export/2025/12" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  --output "deducciones_diciembre_2025.xlsx"
```

Usa este archivo para:
- Integrar con sistema de nómina
- Enviar a contabilidad
- Procesar pagos

**5. Actualizar estado a PROCESADO**
```bash
curl -X PUT "http://localhost:8000/api/apartments/deductions/{deduction_id}/status" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"status": "processed"}'
```

---

## 📋 Tabla Resumen: Todos los Endpoints

| Operación | Endpoint | Método | Parámetros |
|-----------|----------|--------|-----------|
| Ver ocupantes actuales | `/api/apartments/assignments/active` | GET | Ninguno |
| Generar deducciones | `/api/apartments/deductions/generate` | POST | year, month |
| Ver deducciones del mes | `/api/apartments/deductions/{year}/{month}` | GET | apartment_id, employee_id, status |
| Exportar a Excel | `/api/apartments/deductions/export/{year}/{month}` | GET | apartment_id |
| Actualizar estado | `/api/apartments/deductions/{id}/status` | PUT | status (processed/paid/cancelled) |
| Reporte ocupación | `/api/apartments/reports/occupancy` | GET | prefecture, building_name |
| Reporte adeudos | `/api/apartments/reports/arrears` | GET | year, month |
| Reporte mantenimiento | `/api/apartments/reports/maintenance` | GET | period, charge_type |

---

## 💾 Consultas SQL Útiles

### Ver quién vive en cada apartamento (AHORA)

```sql
SELECT
    a.apartment_id,
    apt.code as apartment_code,
    apt.address,
    e.hakenmoto_id,
    e.full_name_kanji,
    e.full_name_kana,
    aa.start_date,
    aa.monthly_rent
FROM apartment_assignments aa
JOIN apartments apt ON aa.apartment_id = apt.id
JOIN employees e ON aa.employee_id = e.hakenmoto_id
WHERE aa.end_date IS NULL
ORDER BY apt.code;
```

**Resultado:**
```
apartment_id | apartment_code | address | hakenmoto_id | full_name_kanji | start_date | monthly_rent
5 | APT-001 | 福岡市中央区 | 156 | 山田太郎 | 2025-12-01 | 45000
6 | APT-002 | 福岡市中央区 | 157 | 鈴木花子 | 2025-11-15 | 55000
```

---

### Ver deducciones del mes con empleados

```sql
SELECT
    d.id,
    d.year,
    d.month,
    e.full_name_kanji,
    apt.code as apartment_code,
    d.base_rent,
    d.additional_charges,
    d.total_amount,
    d.status
FROM deductions d
JOIN apartment_assignments aa ON d.assignment_id = aa.id
JOIN employees e ON aa.employee_id = e.hakenmoto_id
JOIN apartments apt ON aa.apartment_id = apt.id
WHERE d.year = 2025 AND d.month = 12
ORDER BY apt.code;
```

---

### Ver empleados con adeudos

```sql
SELECT
    e.hakenmoto_id,
    e.full_name_kanji,
    SUM(d.total_amount) as total_adeudo,
    COUNT(*) as meses_adeudados
FROM deductions d
JOIN apartment_assignments aa ON d.assignment_id = aa.id
JOIN employees e ON aa.employee_id = e.hakenmoto_id
WHERE d.status IN ('pending', 'processed')
GROUP BY e.hakenmoto_id, e.full_name_kanji
ORDER BY total_adeudo DESC;
```

---

## 🔑 Campos Importantes en Deducciones

| Campo | Significado | Ejemplo |
|-------|-------------|---------|
| `base_rent` | Renta base del apartamento | ¥45,000 |
| `additional_charges` | Cargos (limpieza, reparación, etc.) | ¥5,000 |
| `total_amount` | Total a descontar | ¥50,000 |
| `days_occupied` | Días que ocupó en el mes | 31 |
| `status` | pending/processed/paid/cancelled | pending |
| `year`, `month` | Período de la deducción | 2025, 12 |

---

## 🔐 Permisos Requeridos

| Operación | Rol Mínimo |
|-----------|-----------|
| Ver ocupantes | EMPLOYEE |
| Generar deducciones | COORDINATOR |
| Ver deducciones | COORDINATOR |
| Exportar a Excel | ADMIN |
| Actualizar estado | ADMIN |
| Ver reportes avanzados | ADMIN |

---

## 📱 Ejemplo Completo en la UI

### Paso 1: Ir al Dashboard

```
Home → Departamento → Apartamentos
```

### Paso 2: Ver Ocupación Actual

```
Apartamentos → Ocupación Actual
↓
Tabla con todos los ocupantes:
┌─────────────────────────────────────────┐
│ Apt.  │ Ocupante     │ Entrada   │ Renta│
├─────────────────────────────────────────┤
│APT-001│ 山田太郎     │2025-12-01 │¥45k │
│APT-002│ 鈴木花子     │2025-11-15 │¥55k │
└─────────────────────────────────────────┘
```

### Paso 3: Generar Deducciones del Mes

```
Apartamentos → Deducciones → Generar Mes
↓
Seleccionar año: 2025
Seleccionar mes: 12
Hacer clic: [Generar]
↓
Sistema genera todas las deducciones
```

### Paso 4: Ver Deducciones Generadas

```
Apartamentos → Deducciones → Diciembre 2025
↓
Tabla con todas las deducciones:
┌───────────────────────────────────────────┐
│ Ocupante    │ Apartamento │ Total │Estado │
├───────────────────────────────────────────┤
│ 山田太郎    │ APT-001    │¥50k  │Pending│
│ 鈴木花子    │ APT-002    │¥55k  │Pending│
└───────────────────────────────────────────┘
```

### Paso 5: Exportar a Excel

```
Apartamentos → Deducciones → Diciembre 2025
↓
Botón: [Descargar Excel]
↓
Archivo: deducciones_diciembre_2025.xlsx
(Listo para nómina)
```

---

## ✨ Resumen: Tu Pregunta Respondida

**Tu pregunta:** "Tengo un reporte donde sale quien viven en los apartamentos y cuánto tiene que pagar. Un reporte de arriba abajo con todos los apartamentos hay ? Qué se pueda hacer del 1 al final de mes."

**Respuesta:** ✅ **¡SÍ! El sistema lo hace completamente:**

1. ✅ **Ver quién vive dónde:**
   - Endpoint: `GET /api/apartments/assignments/active`
   - Muestra tabla con ocupantes actuales

2. ✅ **Ver cuánto tienen que pagar:**
   - Endpoint: `GET /api/apartments/deductions/{year}/{month}`
   - Muestra tabla con deducciones mensuales

3. ✅ **Reporte completo (arriba a abajo):**
   - Endpoint: `GET /api/apartments/reports/occupancy`
   - Endpoint: `GET /api/apartments/reports/arrears`
   - Muestra estadísticas, tendencias, deudores

4. ✅ **Del 1 al fin de mes:**
   - **Día 1:** Generar deducciones automáticamente
   - **Durante el mes:** Ver y ajustar si es necesario
   - **Fin de mes:** Exportar a Excel para nómina

**Workflow Automático:**
```
Empleado entra en apartamento
        ↓
Se crea asignación (assignment)
        ↓
Cada mes: Sistema genera deducción automáticamente
        ↓
Deducción se descuenta de nómina
        ↓
Se marca como paid
```

**Puedes hacer reportes:**
- Diarios (ver ocupación actual)
- Mensuales (ver deducciones)
- Trimestrales (ver tendencias)
- Anuales (ver reportes completos)

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
**Estado**: Completamente Documentado ✅
