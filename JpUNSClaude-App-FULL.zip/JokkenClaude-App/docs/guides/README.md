# Development Guides

## Quick Navigation

### Getting Started
- [Development Setup](development-setup.md)
- [Project Structure](project-structure.md)
- [Running the Application](running-application.md)

### Development
- [Backend Development](backend-development.md)
- [Frontend Development](frontend-development.md)
- [Adding New Features](adding-features.md)

### Testing
- [Testing Guide](testing.md)
- [E2E Testing with Playwright](e2e-testing.md)
- [Test Coverage Reports](test-coverage.md)

### Troubleshooting
- [Common Issues](troubleshooting.md)
- [Performance Debugging](performance-debugging.md)
- [Database Issues](database-issues.md)

### Domain Knowledge
- **Yukyu (有給)**: Paid vacation management system
  - Fiscal year: April 1 - March 31 (Japan standard)
  - Deduction formula: days × teiji_hours × hourly_rate
  - Compliance levels: 🟢 ≥5, 🟡 3-5, 🔴 <3

- **RBAC Roles**:
  - KEITOSAN (経理): Accounting/Finance manager
  - TANTOSHA (担当者): HR Manager
  - EMPLOYEE: Regular employee
  - CONTRACT_WORKER: Temporary/contract worker

### Japanese Labor Law
- Monthly working hours calculation
- Overtime regulations
- Paid vacation regulations
- Social insurance requirements
- Tax and deduction rules

---

**Start with [Development Setup](development-setup.md) to get started!**
