# 📚 Guías de JokkenClaude-App

Índice completo de toda la documentación de guías y referencia rápida.

---

## 🚀 Inicio Rápido

**Nuevos usuarios - comienza aquí:**

- **[COMO_EJECUTAR.md](../../COMO_EJECUTAR.md)** - Cómo iniciar la aplicación en 5 minutos
- **[WINDOWS_SETUP.md](../../WINDOWS_SETUP.md)** - Guía completa de setup para Windows (incluye todo lo necesario)
- **[DEPLOYMENT_READINESS.md](../../DEPLOYMENT_READINESS.md)** - Checklist para despliegue a producción

---

## 💼 Flujos de Negocio (CORE FEATURES)

### Contratación - NYUUSHA Workflow (入社連絡票)
- **[NYUUSHA_WORKFLOW.md](NYUUSHA_WORKFLOW.md)** - Flujo completo de contratación
  - Importar candidatos
  - Evaluar candidatos
  - Crear NYUUSHA (formulario de contratación)
  - Llenar datos de empleado
  - Crear empleado final
  - Generar deducción de apartamento

### Gestión de Apartamentos
- **[APARTMENT_REPORTS.md](APARTMENT_REPORTS.md)** - Gestión de vivienda de trabajadores
  - Asignar apartamentos
  - Calcular deducción de renta mensual
  - Reportes de ocupación
  - Detalles de empleados por apartamento

---

## 📤 Importación de Datos

### De Cero (Nuevo Sistema)
- **[DATABASEJP_IMPORT.md](DATABASEJP_IMPORT.md)** - ⭐ **RECOMENDADO** para Windows
  - Importar candidatos desde Access (con fotos OLE automáticas)
  - Importar empleados desde Excel
  - Importar contratistas (UKEOI)
  - Importar personal de oficina (STAFF)
  - Scripts `.bat` para Windows (totalmente automático)

### Migración desde Sistemas Existentes
- **[DATA_MIGRATION.md](DATA_MIGRATION.md)** - Migración general desde bases de datos
  - Mapeo de campos
  - Validación de datos
  - Handling de errores
  - Casos especiales

### Importación Manual
- **[CANDIDATE_IMPORT.md](CANDIDATE_IMPORT.md)** - Cómo importar candidatos
  - Importación manual por interfaz
  - Carga de fotos
  - OCR y extracción de texto
  - Validación de datos

---

## 👨‍💻 Configuración y Desarrollo

### Para Desarrolladores
- **[development-setup.md](development-setup.md)** - Setup local para desarrollo
  - Instalar dependencias
  - Configurar base de datos
  - Ejecutar tests
  - Estructuración del código

### Estructura del Proyecto
- **[README.md](README.md)** - Descripción de componentes y estructura
  - Componentes React
  - Módulos principales
  - Arquitectura de carpetas

---

## 🏗️ Arquitectura y Infraestructura

### Descripción de Arquitectura
- **[../architecture/README.md](../architecture/README.md)** - Diagrama y descripción de la arquitectura
  - Stack tecnológico
  - Componentes del sistema
  - Flujos de datos

### Monitoreo y CI/CD
- **[../MONITORING_QUICKSTART.md](../MONITORING_QUICKSTART.md)** - Cómo acceder a dashboards de monitoreo
- **[../deployment/CICD_MONITORING_COMPLETE_SUMMARY.md](../deployment/CICD_MONITORING_COMPLETE_SUMMARY.md)** - Documentación completa de CI/CD y Monitoring
  - GitHub Actions
  - Prometheus
  - Grafana
  - Alertas

### Pasos Completos (Del Inicio al Final)
- **[../PASOS_COMPLETOS_INICIO_A_FIN.md](../PASOS_COMPLETOS_INICIO_A_FIN.md)** - Guía paso a paso de todas las fases
  - Fase 1: Setup inicial
  - Fase 2: Configuración
  - ... hasta Fase 8: Automatización

---

## 🤖 Scripts de Automatización (Windows)

Todos estos scripts están en la raíz del proyecto y son completamente automáticos:

### Importación Individual
- **[../../IMPORTAR_CANDIDATOS.bat](../../IMPORTAR_CANDIDATOS.bat)** - Importar candidatos con fotos OLE
- **[../../IMPORTAR_EMPLEADOS.bat](../../IMPORTAR_EMPLEADOS.bat)** - Importar empleados HAKEN (派遣社員)
- **[../../IMPORTAR_UKEOI.bat](../../IMPORTAR_UKEOI.bat)** - Importar contratistas UKEOI (請負社員)
- **[../../IMPORTAR_STAFF.bat](../../IMPORTAR_STAFF.bat)** - Importar personal STAFF (スタッフ)

### Importación Completa
- **[../../IMPORTAR_TODO.bat](../../IMPORTAR_TODO.bat)** - Importar TODO en orden correcto
  - Fase 1: Candidatos
  - Fase 2: Empleados HAKEN
  - Fase 3: UKEOI (si existe)
  - Fase 4: STAFF (si existe)

### Documentación de Scripts
- **[../../IMPORTAR_SCRIPTS_README.txt](../../IMPORTAR_SCRIPTS_README.txt)** - Guía completa de scripts
  - Preparación (una sola vez)
  - Cómo usar cada script
  - Solución de problemas
  - Información técnica de extracción OLE

---

## 📋 Otros Documentos Importantes

- **[../../CHECKLIST_COMPLETO.md](../../CHECKLIST_COMPLETO.md)** - Verificación de que todos los archivos están presentes
  - Archivos críticos
  - Dependencias verificadas
  - Estado de cada sección
  - Checklist antes de usar

- **[../../README.md](../../README.md)** - Descripción principal del proyecto
- **[../../MIGRACION_README.txt](../../MIGRACION_README.txt)** - Instrucciones de migración (formato texto)

---

## 🎯 Guía Rápida por Caso de Uso

### "Acabo de instalar, ¿qué hago?"
1. Leer: [COMO_EJECUTAR.md](../../COMO_EJECUTAR.md) (5 min)
2. Leer: [WINDOWS_SETUP.md](../../WINDOWS_SETUP.md) si usas Windows
3. Ejecutar: `./START.bat` (Windows) o `./START.sh` (Linux)
4. Ir a: http://localhost:3000
5. Login: admin@example.com / admin_password_123

### "Tengo candidatos en Access con fotos, ¿cómo los importo?"
1. Leer: [DATABASEJP_IMPORT.md](DATABASEJP_IMPORT.md)
2. Ejecutar: `IMPORTAR_CANDIDATOS.bat` en Windows
   - O seguir instrucciones para Linux
3. Verificar en: http://localhost:3000 → Reclutamiento → Candidatos

### "Tengo empleados en Excel, ¿cómo los importo?"
1. Leer: [DATABASEJP_IMPORT.md](DATABASEJP_IMPORT.md)
2. Ejecutar: `IMPORTAR_EMPLEADOS.bat` en Windows
3. Verificar en: http://localhost:3000 → Personal → Empleados

### "Quiero importar TODO de una vez"
1. Leer: [DATABASEJP_IMPORT.md](DATABASEJP_IMPORT.md)
2. Ejecutar: `IMPORTAR_TODO.bat` en Windows
   - Importa en orden: Candidatos → Empleados → UKEOI → STAFF
3. Verificar en: http://localhost:3000 → Todas las secciones

### "Quiero entender cómo funciona la contratación"
1. Leer: [NYUUSHA_WORKFLOW.md](NYUUSHA_WORKFLOW.md)
2. Seguir el ejemplo paso a paso
3. Practicar en la interfaz

### "Necesito gestionar apartamentos de trabajadores"
1. Leer: [APARTMENT_REPORTS.md](APARTMENT_REPORTS.md)
2. Ir a: http://localhost:3000 → Apartamentos
3. Asignar apartamentos a empleados
4. Ver deducción de renta automática

### "Voy a desplegar a producción"
1. Leer: [DEPLOYMENT_READINESS.md](../../DEPLOYMENT_READINESS.md)
2. Leer: [../deployment/CICD_MONITORING_COMPLETE_SUMMARY.md](../deployment/CICD_MONITORING_COMPLETE_SUMMARY.md)
3. Completar el checklist
4. Desplegar siguiendo los pasos

---

## 🔗 Estructura de Links

Todos los links en esta documentación son **relativos** para funcionar en:
- ✅ GitHub (web)
- ✅ Editor local (VS Code, etc.)
- ✅ HTML rendered
- ✅ Markdown viewers

Si un link no funciona, es por una ruta incorrecta. Reportar en GitHub Issues.

---

## 🆘 Obtener Ayuda

**Si tienes problemas:**

1. Buscar en los documentos (Ctrl+F)
2. Leer la sección "Solución de Problemas" en el documento relevante
3. Verificar [CHECKLIST_COMPLETO.md](../../CHECKLIST_COMPLETO.md)
4. Reportar en GitHub Issues con:
   - Qué intentaste hacer
   - Qué error obtuviste
   - En qué documento estabas
   - Tu sistema operativo y versiones

---

## 📅 Actualización de Documentación

- **Última actualización**: 2025-11-22
- **Versión documentación**: 1.0.0
- **Estado**: ✅ Completo para v6.0.0

---

**🎯 Próximo paso**: Elige tu caso de uso arriba y comienza a leer la documentación relevante.
