# Architecture Documentation

## Overview

JokkenClaude-App is built with a clean, scalable architecture designed for the JPUNS Yukyu Management System.

### Core Components

**Backend (FastAPI)**
- SQLAlchemy 2.0 ORM with async support
- Role-Based Access Control (RBAC)
- Comprehensive error handling & logging
- Resilience patterns (circuit breakers, retries)
- Caching strategy with Redis

**Frontend (Next.js + React)**
- Server-side rendering for performance
- TypeScript for type safety
- Component-based architecture
- Custom hooks for business logic
- Responsive UI with Tailwind CSS

**Infrastructure**
- Docker containerization
- Docker Compose for orchestration
- Prometheus + Grafana monitoring
- Alertmanager for notifications
- GitHub Actions CI/CD

**Database**
- PostgreSQL 15
- Alembic for migrations
- Optimized indexes and triggers
- JSONB for flexible data storage

### Key Architectural Decisions

1. **Separation of Concerns**: API routes, services, models, schemas clearly separated
2. **Service Layer**: Business logic in services, not endpoints
3. **Dependency Injection**: FastAPI dependencies for DB sessions, auth, etc.
4. **Response Wrapper**: Standardized API responses (success_response, created_response)
5. **RBAC**: Role-based page visibility and action permissions
6. **Caching**: Redis-backed caching with parameter-based keys
7. **Error Handling**: Custom exceptions with detailed error messages
8. **Monitoring**: Prometheus metrics for observability

### Technology Stack Details

See individual guide files for specific technologies:
- [API Design Patterns](api-design.md)
- [Database Schema](../database/schema.md)
- [Security Architecture](../security/overview.md)
- [Performance Considerations](performance.md)

---

For more detailed information, see the deployment and development guides.
