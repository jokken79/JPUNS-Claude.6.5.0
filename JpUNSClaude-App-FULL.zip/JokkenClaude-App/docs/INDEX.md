# JokkenClaude-App Documentation Index

## 📚 Documentation Overview

Complete documentation for the JPUNS Yukyu Management System - clean, production-ready, fully functional.

### Quick Links

**Getting Started** (5-10 minutes)
- [README.md](../README.md) - Project overview
- [Setup Guide](guides/development-setup.md) - Local development setup
- [Running Application](guides/running-application.md) - Start & access the app

**Key Guides** (10-30 minutes)
- [Architecture Overview](architecture/README.md) - System design
- [Project Structure](guides/project-structure.md) - File organization
- [API Reference](api/README.md) - API endpoints
- [Database Schema](database/schema.md) - Data model
- [NYUUSHA Workflow](guides/NYUUSHA_WORKFLOW.md) - Complete employee onboarding process
- [Apartment Reports](guides/APARTMENT_REPORTS.md) - Occupancy and rent billing reports
- [Candidate Import](guides/CANDIDATE_IMPORT.md) - Import candidates with OCR and photos

**Development** (30+ minutes)
- [Backend Development](guides/backend-development.md) - API development
- [Frontend Development](guides/frontend-development.md) - UI development
- [Adding Features](guides/adding-features.md) - Step-by-step feature addition
- [Testing Guide](guides/testing.md) - Writing tests
- [E2E Testing](guides/e2e-testing.md) - Playwright tests

**Operations** (15-45 minutes)
- [Deployment Guide](deployment/README.md) - Production deployment
- [Monitoring Setup](deployment/monitoring.md) - Prometheus + Grafana
- [CI/CD Pipeline](deployment/cicd.md) - GitHub Actions
- [Troubleshooting](guides/troubleshooting.md) - Common issues

**Reference** (As needed)
- [Complete Setup Guide](PASOS_COMPLETOS_INICIO_A_FIN.md) - Step-by-step from start to finish
- [Monitoring Quickstart](MONITORING_QUICKSTART.md) - Quick monitoring setup
- [CI/CD Summary](deployment/CICD_MONITORING_COMPLETE_SUMMARY.md) - Deployment summary
- [Data Migration](guides/DATA_MIGRATION.md) - Migrate existing data from Excel and databases
- [DATABASEJP Automatic Import](guides/DATABASEJP_IMPORT.md) - Automatic migration from Access database with OLE photos

---

## 📖 Navigation by Role

### 👨‍💻 Developer
1. [Development Setup](guides/development-setup.md)
2. [Project Structure](guides/project-structure.md)
3. [Backend Development](guides/backend-development.md) OR [Frontend Development](guides/frontend-development.md)
4. [Testing Guide](guides/testing.md)
5. [Troubleshooting](guides/troubleshooting.md)

### 🚀 DevOps / Operations
1. [Deployment Guide](deployment/README.md)
2. [Monitoring Setup](deployment/monitoring.md)
3. [CI/CD Pipeline](deployment/cicd.md)
4. [Complete Setup Guide](PASOS_COMPLETOS_INICIO_A_FIN.md)
5. [Data Migration](guides/DATA_MIGRATION.md) - Import existing data from Excel and databases

### 📊 Architect / Tech Lead
1. [Architecture Overview](architecture/README.md)
2. [API Reference](api/README.md)
3. [Database Schema](database/schema.md)
4. [Security Overview](../docs/security/README.md) (if available)
5. [Performance Guide](architecture/performance.md)

### 👤 New Team Member
1. [README.md](../README.md) - What is this project?
2. [Development Setup](guides/development-setup.md) - How do I get started?
3. [Project Structure](guides/project-structure.md) - How is it organized?
4. [Architecture Overview](architecture/README.md) - How does it work?
5. [Adding Features](guides/adding-features.md) - How do I add features?

---

## 🔑 Key Concepts

### 入社連絡票 (Nyuusha) - New Hire Notification Form
- **Step 1**: Auto-created when candidate is approved after interview
- **Step 2**: Admin fills employee data (factory, hire date, position, salary, bank account, apartment)
- **Step 3**: Admin approves → Automatically creates Employee record
- Complete guide: [NYUUSHA Workflow](guides/NYUUSHA_WORKFLOW.md)

### 住宅 (Housing) - Apartment Management
- **Occupancy**: Track who lives in each apartment (active assignments)
- **Billing**: Auto-generate monthly rent deductions from salary
- **Prorated Rent**: Calculate partial month rent when employee moves in/out
- **Additional Charges**: Track cleaning, repairs, deposits per apartment
- **Reports**: Occupancy rates, arrears, maintenance by period
- Complete guide: [Apartment Reports](guides/APARTMENT_REPORTS.md)

### 候補者管理 (Candidate Management) - Recruitment
- **Manual Import**: Fill Rirekisho form with photo (auto-compressed 800x1000 px)
- **OCR Import**: Upload document (photo, PDF) → Auto-extract data
- **Document Types**: Rirekisho, Zairyu Card, Driver's License
- **Photo Validation**: Auto-compress, validate format, max 10 MB
- **Workflow**: Import → Evaluate → Approve → Create NYUUSHA → Create Employee
- Complete guide: [Candidate Import](guides/CANDIDATE_IMPORT.md)

### Yukyu (有給) - Paid Vacation
- Fiscal year: **April 1 - March 31** (Japan standard)
- Calculation: `days × teiji_hours × hourly_rate`
- Compliance: 🟢 ≥5 days, 🟡 3-5 days, 🔴 <3 days
- Management: Request, approve, track, report

### RBAC Roles
- **KEITOSAN** (経理): Accounting/Finance manager
- **TANTOSHA** (担当者): HR Manager
- **EMPLOYEE**: Regular employee
- **CONTRACT_WORKER**: Temporary worker

### Technology Stack
| Component | Technology |
|-----------|-----------|
| Backend API | FastAPI + SQLAlchemy |
| Frontend UI | Next.js + React + TypeScript |
| Database | PostgreSQL 15 |
| Cache | Redis |
| Monitoring | Prometheus + Grafana |
| Testing | pytest + Playwright |
| CI/CD | GitHub Actions |
| Containerization | Docker + Docker Compose |

---

## 📋 Documentation Checklist

- [x] Project README with overview
- [x] Setup & installation guide
- [x] Development workflow documentation
- [x] API reference
- [x] Architecture documentation
- [x] Testing procedures
- [x] Deployment procedures
- [x] Monitoring setup
- [x] Troubleshooting guide
- [x] CI/CD documentation

---

## 🔄 Document Maintenance

These documents are maintained as the system evolves. When making changes:

1. Update relevant doc files
2. Update INDEX.md if adding new docs
3. Keep examples and commands up-to-date
4. Note any breaking changes

---

## 💡 Tips

- **Lost?** Start with [README.md](../README.md)
- **Want to code?** Go to [Development Setup](guides/development-setup.md)
- **Deploying?** See [Deployment Guide](deployment/README.md)
- **Stuck?** Check [Troubleshooting](guides/troubleshooting.md)
- **Looking for something?** Use Ctrl+F to search this page

---

**Last Updated**: 2025-11-22
**Version**: 1.0.0
**Status**: Production Ready ✅
