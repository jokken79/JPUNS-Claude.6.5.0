=================================================================
MIGRACIÓN AUTOMÁTICA DESDE CARPETA DATABASEJP
=================================================================

REQUISITOS:
-----------
1. Windows con Python 3.8+
2. Instalación de Docker con JokkenClaude-App corriendo
3. Aplicación accesible en http://localhost:8000

PREPARACIÓN (Una sola vez):
----------------------------

1. CREAR CARPETA
   mkdir C:\Users\TuNombre\DATABASEJP

2. COPIAR ARCHIVOS A LA CARPETA
   - Tu archivo Access (base_datos.mdb o base_datos.accdb)
   - Tu Excel con empleados (empleados.xlsx)

   La carpeta debe verse así:
   C:\Users\TuNombre\DATABASEJP\
   ├── base_datos.mdb
   └── empleados.xlsx

3. INSTALAR DEPENDENCIAS (PowerShell como Administrator)
   pip install pyodbc pandas Pillow requests

4. INSTALAR ACCESS DATABASE ENGINE (Windows)
   Descargar e instalar desde:
   https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255

   Elegir versión:
   - AccessDatabaseEngine_X64.exe (para Windows 64-bit)
   - AccessDatabaseEngine.exe (para Windows 32-bit)

CÓMO USAR:
----------

1. INICIAR LA APLICACIÓN
   ./START.bat
   (O seleccionar opción 1)

2. OBTENER TOKEN API
   - Abrir http://localhost:3000
   - Login como admin@example.com / admin_password_123
   - Ir a Settings → API Token
   - Copiar el token

3. EJECUTAR MIGRACIÓN
   python3 migracion_databasejp.py "tu_token_aqui"

   Ejemplo:
   python3 migracion_databasejp.py "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

4. ESPERAR RESULTADOS
   El script mostrará:
   ✓ Empleados importados
   ✓ Candidatos importados
   ✓ Fotos extraídas de OLE y convertidas a Base64

QUÉ PASA AUTOMÁTICAMENTE:
--------------------------

FASE 1: Importar Empleados
  - Lee Excel (empleados.xlsx)
  - Mapea columnas automáticamente
  - Importa a la BD de JokkenClaude-App

FASE 2: Importar Candidatos con Fotos OLE
  - Conecta a Access (base_datos.mdb/.accdb)
  - Lee tabla "candidates"
  - Extrae fotos del formato OLE
  - Convierte JPEG OLE → Base64
  - Importa candidatos con fotos a la app

SOLUCIÓN DE PROBLEMAS:
----------------------

❌ "pyodbc not found"
   Solución: pip install pyodbc

❌ "Microsoft Access Driver not found"
   Solución: Instalar Access Database Engine (ver arriba)

❌ "JPEG start marker not found"
   Solución: Las fotos están dañadas en Access
   - Verificar que las fotos se ven bien en Access
   - Si no, re-guardar las fotos

❌ "Connection failed"
   Solución:
   - Asegurate que el archivo no está abierto en Access
   - Asegurate que la ruta es correcta
   - Asegurate que la tabla se llama "candidates"

❌ "Token invalid"
   Solución: Obtener token nuevo desde Settings → API Token

❌ "Connection refused" a http://localhost:8000
   Solución: Asegurate que la app está corriendo
   - Ejecutar START.bat si no está corriendo
   - Esperar a que inicie (15 segundos)

VERIFICACIÓN:
--------------

1. Abrir http://localhost:3000
2. Ir a Reclutamiento → Candidatos
3. Ver que aparecen los candidatos importados CON FOTOS
4. Ir a Personal → Empleados
5. Ver que aparecen los empleados importados

PRÓXIMOS PASOS:
----------------

1. Evaluar candidatos (entrevista, resultado)
2. Aprobar candidatos
3. Sistema auto-crea formulario NYUUSHA
4. Llenar datos de empleado (factory, hire_date, posición, etc.)
5. Aprobar NYUUSHA
6. Sistema crea registro en tabla de empleados
7. Sistema genera deducción de apartamento automáticamente

Para más información, ver:
  /home/user/JokkenClaude-App/docs/guides/DATABASEJP_IMPORT.md

=================================================================
