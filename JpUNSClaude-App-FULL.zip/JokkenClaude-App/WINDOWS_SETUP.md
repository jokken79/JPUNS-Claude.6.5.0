# 🪟 Guía de Setup para Windows - JokkenClaude-App

## ✅ Requisitos Previos

### 1️⃣ Docker Desktop (OBLIGATORIO)
- **Descargar**: https://www.docker.com/products/docker-desktop
- **Versión mínima**: 4.0+
- **Espacio requerido**: 5+ GB
- **RAM**: Mínimo 4 GB (recomendado 8 GB)
- **Windows Version**: Windows 10 (build 19041+) o Windows 11

### 2️⃣ Verificar WSL 2 (Automatizado con Docker Desktop)
Docker Desktop en Windows usa **WSL 2** (Windows Subsystem for Linux).

Para verificar que WSL 2 está instalado:
```bash
wsl --version
```

Si no está instalado, Docker Desktop lo instalará automáticamente.

### 3️⃣ Git (OPCIONAL pero recomendado)
- **Descargar**: https://git-scm.com/download/win
- **Usar**: Git Bash para ejecutar scripts (START.sh)

---

## 🚀 OPCIÓN A: Método Rápido (Recomendado para Windows)

### Paso 1: Copiar .env
```bash
# En PowerShell o CMD, dentro de JokkenClaude-App/
copy .env.example .env
```

### Paso 2: Ejecutar START.bat
```bash
# Doble-click en START.bat
# O desde CMD/PowerShell:
./START.bat
```

**El menú te mostrará opciones:**
```
1) Start complete application (Default)
2) Start backend + database only
3) Start frontend only
4) Show services status
5) Stop all services
6) View logs (live)
7) Restart services
8) Clean and restart from scratch
```

### Paso 3: Acceder a la aplicación
- **Frontend**: http://localhost:3000
- **Backend**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **Grafana**: http://localhost:3001

---

## 🛠️ OPCIÓN B: Usando Git Bash (Si tienes Git instalado)

Si instalaste **Git para Windows**, puedes usar `bash`:

### Paso 1: Abrir Git Bash
```bash
# En Windows, busca "Git Bash"
# O: Win + R → git-bash
```

### Paso 2: Navegar a la carpeta
```bash
cd /c/Users/TuNombre/JokkenClaude-App
```

### Paso 3: Copiar .env
```bash
cp .env.example .env
```

### Paso 4: Ejecutar START.sh
```bash
./START.sh
```

---

## 📋 Comandos Docker para Windows

### Ver estado de servicios
```bash
docker-compose ps
```

### Ver logs en tiempo real
```bash
docker-compose logs -f
```

### Ver logs de un servicio específico
```bash
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f db
```

### Detener servicios
```bash
docker-compose stop
```

### Detener y remover TODO (incluyendo datos)
```bash
docker-compose down -v
```

### Reiniciar un servicio
```bash
docker-compose restart backend
```

### Acceder a la base de datos
```bash
docker-compose exec db psql -U uns_admin -d uns_claudejp
```

---

## 🐛 Troubleshooting para Windows

### ❌ ERROR: "docker-compose: command not found"

**Solución 1**: Asegurar que Docker Desktop está corriendo
- Ve a Windows → Busca "Docker Desktop" → Abre la aplicación
- Espera a que aparezca el ícono en la bandeja del sistema

**Solución 2**: En PowerShell, usar:
```powershell
docker compose up -d
# En lugar de:
# docker-compose up -d
```

### ❌ ERROR: "Port 3000 is already in use"

**Solución**:
```bash
# Encuentra qué está usando el puerto
netstat -ano | findstr :3000

# Mata el proceso (reemplaza PID)
taskkill /PID 1234 /F

# O simplemente cambia el puerto en docker-compose.yml
# Busca la línea: "3000:3000"
# Cambia a: "3001:3000"
```

### ❌ ERROR: "Docker daemon is not running"

**Solución**:
- Abre Docker Desktop desde el Start Menu
- Espera ~30 segundos a que inicie
- Intenta de nuevo

### ❌ ERROR: "Cannot connect to database"

**Solución**:
```bash
# Ver logs de la base de datos
docker-compose logs db

# Reiniciar la base de datos
docker-compose restart db

# Esperar 30 segundos y reintentar
```

### ❌ ERROR: "BUILD FAILED" en Docker

**Solución 1**: Limpiar cache
```bash
docker system prune -a
docker-compose build --no-cache
docker-compose up -d
```

**Solución 2**: Verificar espacio en disco
```bash
# En PowerShell
Get-Volume
# Asegurar al menos 10 GB libres
```

### ❌ Frontend/Backend muy lento en Windows

**Problema**: WSL 2 en Windows puede ser lento con archivos en /mnt/c/

**Solución**:
1. Mover JokkenClaude-App a WSL filesystem:
```bash
# En WSL 2:
mkdir ~/projects
cp -r /mnt/c/Users/.../JokkenClaude-App ~/projects/
cd ~/projects/JokkenClaude-App
docker-compose up -d
```

2. O aumentar recursos en Docker:
   - Docker Desktop → Settings → Resources
   - Aumentar CPU a 4+ cores
   - Aumentar Memory a 8+ GB

---

## 🔒 Configuración de Seguridad para Desarrollo Local

En `docker-compose.yml` están comentadas las lines de producción. Para desarrollo local con Windows:

### Las Variables Críticas a Cambiar:

1. **SECRET_KEY** en `.env`:
```bash
# Generar una clave segura (en PowerShell):
[System.Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
```

2. **POSTGRES_PASSWORD** en `.env`:
```
POSTGRES_PASSWORD=your-secure-password
```

3. **REDIS_PASSWORD** en `.env`:
```
REDIS_PASSWORD=your-redis-password
```

---

## 📊 Monitoreo en Windows

### Usar Windows Task Manager para ver Docker
1. Abre Task Manager (Ctrl + Shift + Esc)
2. Busca procesos que comiencen con "docker"
3. Verifica uso de CPU/RAM

### Usar Docker Desktop Dashboard
- Docker Desktop tiene un UI visual
- Puedes ver todos los containers
- Ver logs en tiempo real
- Pausar/reiniciar containers

---

## 🎯 Flujo Completo para Windows

### 1. Instalación Inicial

```bash
# 1. Instalar Docker Desktop
#    (Desde: https://www.docker.com/products/docker-desktop)

# 2. Abrir CMD o PowerShell como Administrator

# 3. Navegar a la carpeta
cd C:\Users\TuNombre\JokkenClaude-App

# 4. Copiar .env
copy .env.example .env

# 5. Ejecutar START.bat
START.bat

# 6. Seleccionar opción: 1 (Start complete application)

# 7. Esperar 15 segundos
```

### 2. Acceder a la Aplicación

Abre tu navegador:
- http://localhost:3000 (Frontend)
- http://localhost:8000/docs (Backend API)

**Credenciales por defecto:**
```
Email: admin@example.com
Password: admin_password_123
```

### 3. Desarrollo Diario

```bash
# Ver logs mientras desarrollas
docker-compose logs -f backend

# Si necesitas cambiar código, reinicia el servicio
docker-compose restart backend

# Para ver estado en cualquier momento
docker-compose ps
```

### 4. Detener al terminar

```bash
# Opción 1: Desde START.bat
START.bat
# Seleccionar 5 (Stop all services)

# Opción 2: Desde command line
docker-compose down
```

---

## 🔄 Actualizar Variables de Entorno

Si cambias el `.env`:

```bash
# Recrear containers con nuevo .env
docker-compose down
docker-compose up -d
```

---

## 📱 Acceso desde Otro Equipo en la Red (Opcional)

Si quieres acceder desde otra máquina Windows en tu red:

1. Obtener IP de tu máquina:
```bash
ipconfig
# Buscar: IPv4 Address (ej: 192.168.1.100)
```

2. En otra máquina, abrir:
```
http://192.168.1.100:3000
http://192.168.1.100:8000/docs
```

**Nota**: Esto solo funciona en la misma red local. Para internet, necesitas port forwarding/VPN.

---

## 🆘 Soporte

Si algo no funciona:

1. **Ver logs detallados**:
```bash
docker-compose logs -f
```

2. **Reiniciar Docker Desktop**:
   - Click derecho en el ícono de Docker
   - "Restart"

3. **Limpiar todo y empezar de nuevo**:
```bash
docker-compose down -v
docker system prune -a
# Abre Docker Desktop nuevamente
docker-compose up -d
```

4. **Verificar que Docker tiene suficientes recursos**:
   - Docker Desktop → Settings → Resources
   - CPU: ≥ 4 cores
   - Memory: ≥ 8 GB
   - Disk: ≥ 10 GB libres

---

## ✅ Checklist de Verificación

- [ ] Docker Desktop instalado y corriendo
- [ ] WSL 2 disponible (automático con Docker)
- [ ] JokkenClaude-App carpeta existe
- [ ] .env copiado de .env.example
- [ ] START.bat ejecutado correctamente
- [ ] Todos los containers iniciaron (docker-compose ps)
- [ ] http://localhost:3000 carga
- [ ] http://localhost:8000/docs carga
- [ ] Puedo ver la aplicación
- [ ] Puedo iniciar sesión (admin@example.com / admin_password_123)

---

**Última actualización**: 2025-11-22
**Sistema Operativo**: Windows 10/11 + Docker Desktop
**Estado**: ✅ Probado en Windows
