/** @type {import('next').NextConfig} */
const nextConfig = {
  // ========================================
  // React & Performance
  // ========================================
  reactStrictMode: true,
  swcMinify: true,

  // ========================================
  // Image Optimization
  // ========================================
  images: {
    unoptimized: true,
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      {
        protocol: 'http',
        hostname: 'localhost',
      },
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },

  // ========================================
  // TypeScript & ESLint
  // ========================================
  typescript: {
    ignoreBuildErrors: false,
  },
  eslint: {
    ignoreDuringBuilds: false,
  },

  // ========================================
  // Compiler Options
  // ========================================
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
    styledComponents: true,
  },

  // ========================================
  // Experimental Features
  // ========================================
  experimental: {
    optimizePackageImports: ['@radix-ui/react-icons'],
  },

  // ========================================
  // Security Headers & Caching
  // ========================================
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=3600' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
        ],
      },
      {
        source: '/api/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-cache' },
        ],
      },
    ];
  },

  // ========================================
  // Redirects & Rewrites
  // ========================================
  async redirects() {
    return [
      {
        source: '/',
        destination: '/dashboard',
        permanent: true,
      },
    ];
  },

  async rewrites() {
    return {
      beforeFiles: [
        {
          source: '/api/:path*',
          destination: 'http://localhost:8000/api/:path*',
        },
      ],
    };
  },

  // ========================================
  // Environment Variables
  // ========================================
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000',
    NEXT_PUBLIC_APP_NAME: 'UNS-ClaudeJP',
    NEXT_PUBLIC_APP_VERSION: '6.0.0',
  },

  // ========================================
  // Webpack Configuration
  // ========================================
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.optimization.splitChunks.cacheGroups = {
        ...config.optimization.splitChunks.cacheGroups,
        radix: {
          test: /@radix-ui/,
          name: 'radix',
          priority: 20,
        },
      };
    }
    return config;
  },
};

module.exports = nextConfig;
