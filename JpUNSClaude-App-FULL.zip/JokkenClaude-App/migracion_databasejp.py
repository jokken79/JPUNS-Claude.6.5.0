#!/usr/bin/env python3
"""
Migración automática desde carpeta DATABASEJP
- Lee Access con candidatos + fotos OLE
- Lee Excel con empleados
- Importa a JokkenClaude-App automáticamente

Uso:
  python3 migracion_databasejp.py <your_api_token>

Ejemplo:
  python3 migracion_databasejp.py "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
"""

import os
import json
import logging
import base64
import requests
import pandas as pd
from pathlib import Path
from typing import Optional, Dict, List
import io
import sys

# Intentar importar pyodbc (requerido para Windows + Access)
try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    PYODBC_AVAILABLE = False

# Intentar importar PIL (requerido para validar imágenes)
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class OLEImageExtractor:
    """Extrae imágenes JPEG puras de objetos OLE en Access"""

    # Signatures de imagen
    JPEG_START = b'\xff\xd8\xff'  # SOI (Start of Image)
    JPEG_END = b'\xff\xd9'         # EOI (End of Image)

    @staticmethod
    def extract_jpeg_from_ole(ole_bytes: bytes) -> Optional[bytes]:
        """
        Extrae JPEG puro de objeto OLE

        Las fotos OLE en Access tienen:
        - Bytes OLE iniciales (header)
        - JPEG embebido
        - Bytes OLE finales (footer)

        Encuentra y extrae solo la parte JPEG
        """
        if not ole_bytes or len(ole_bytes) < 100:
            return None

        try:
            # Buscar inicio de JPEG
            start_idx = ole_bytes.find(OLEImageExtractor.JPEG_START)
            if start_idx == -1:
                logger.warning("JPEG start marker not found in OLE object")
                return None

            # Buscar fin de JPEG
            end_idx = ole_bytes.find(OLEImageExtractor.JPEG_END, start_idx)
            if end_idx == -1:
                logger.warning("JPEG end marker not found in OLE object")
                return None

            # Extraer JPEG (incluir end marker)
            end_idx += len(OLEImageExtractor.JPEG_END)
            jpeg_data = ole_bytes[start_idx:end_idx]

            # Validar que es JPEG válido
            if PIL_AVAILABLE:
                try:
                    Image.open(io.BytesIO(jpeg_data))
                    logger.info(f"✓ JPEG válido extraído ({len(jpeg_data)} bytes)")
                    return jpeg_data
                except Exception as e:
                    logger.error(f"✗ JPEG extraído es inválido: {e}")
                    return None
            else:
                # Si no tenemos PIL, confiar en que es válido
                logger.info(f"✓ JPEG extraído ({len(jpeg_data)} bytes)")
                return jpeg_data

        except Exception as e:
            logger.error(f"Error extrayendo JPEG de OLE: {e}")
            return None

    @staticmethod
    def ole_to_base64(ole_bytes: bytes) -> Optional[str]:
        """Convierte OLE → JPEG → Base64"""
        jpeg_data = OLEImageExtractor.extract_jpeg_from_ole(ole_bytes)
        if not jpeg_data:
            return None

        b64_str = base64.b64encode(jpeg_data).decode('utf-8')
        return f"data:image/jpeg;base64,{b64_str}"


class AccessDatabaseReader:
    """Lee datos de base de datos Access (.mdb/.accdb)"""

    def __init__(self, db_path: str):
        if not PYODBC_AVAILABLE:
            raise ImportError(
                "pyodbc no está instalado. Instala con: pip install pyodbc"
            )

        self.db_path = db_path
        self.conn_string = None
        self._setup_connection_string()

    def _setup_connection_string(self):
        """Configura connection string según versión de Access"""
        if self.db_path.endswith('.mdb'):
            # Access 2003 y anteriores
            self.conn_string = f"Driver={{Microsoft Access Driver (*.mdb)}};DBQ={self.db_path};"
        elif self.db_path.endswith('.accdb'):
            # Access 2007+
            self.conn_string = f"Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self.db_path};"
        else:
            raise ValueError("Solo .mdb y .accdb son soportados")

    def get_candidates_with_photos(self) -> List[Dict]:
        """
        Lee candidatos de Access con fotos OLE

        Busca tabla "candidates" con columnas:
        - id, full_name_kanji, full_name_kana, date_of_birth,
          gender, nationality, email, phone, address, photo (OLE)
        """
        candidates = []

        try:
            conn = pyodbc.connect(self.conn_string)
            cursor = conn.cursor()

            # Leer tabla candidates
            cursor.execute("SELECT * FROM candidates")
            columns = [desc[0] for desc in cursor.description]

            logger.info(f"Columnas encontradas: {columns}")

            for row in cursor.fetchall():
                candidate_dict = dict(zip(columns, row))

                # Si tiene foto OLE, extraer
                photo_data_url = None
                photo_key = None

                # Buscar columna de foto (puede tener varios nombres)
                for possible_key in ['photo', 'photo_data', 'photo_ole', 'imagen', 'image']:
                    if possible_key in candidate_dict:
                        photo_key = possible_key
                        break

                if photo_key:
                    ole_data = candidate_dict.get(photo_key)

                    if ole_data:
                        name = candidate_dict.get('full_name_kanji', 'Unknown')
                        logger.info(f"Procesando foto OLE para {name}")
                        photo_data_url = OLEImageExtractor.ole_to_base64(ole_data)

                        if photo_data_url:
                            logger.info(f"✓ Foto extraída exitosamente")
                        else:
                            logger.warning(f"✗ No se pudo extraer foto para {name}")

                candidates.append({
                    "id": candidate_dict.get("id"),
                    "full_name_kanji": candidate_dict.get("full_name_kanji"),
                    "full_name_kana": candidate_dict.get("full_name_kana"),
                    "date_of_birth": candidate_dict.get("date_of_birth"),
                    "gender": candidate_dict.get("gender"),
                    "nationality": candidate_dict.get("nationality"),
                    "email": candidate_dict.get("email"),
                    "phone": candidate_dict.get("phone"),
                    "address": candidate_dict.get("address"),
                    "photo_data_url": photo_data_url
                })

            conn.close()
            logger.info(f"✓ {len(candidates)} candidatos leídos de Access")
            return candidates

        except Exception as e:
            logger.error(f"Error leyendo Access: {e}")
            logger.info("Asegurate que:")
            logger.info("  1. Access/Database Engine está instalado en Windows")
            logger.info("  2. La ruta del archivo es correcta")
            logger.info("  3. La tabla se llama 'candidates'")
            logger.info("  4. El archivo no está abierto en Access")
            return []


class JokkenImporter:
    """Importa datos a JokkenClaude-App"""

    def __init__(self, api_url: str, token: str):
        self.api_url = api_url
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

    def import_employees_from_excel(self, excel_path: str) -> Dict:
        """Importa empleados desde Excel"""
        logger.info(f"Importando empleados desde {excel_path}")

        try:
            with open(excel_path, 'rb') as f:
                files = {'file': f}
                headers_file = {"Authorization": f"Bearer {self.token}"}

                response = requests.post(
                    f"{self.api_url}/api/import-export/employees",
                    headers=headers_file,
                    files=files
                )

            if response.status_code == 200:
                result = response.json()
                success = result.get('data', {}).get('successful_imports', 0)
                failed = result.get('data', {}).get('failed_imports', 0)

                logger.info(f"✓ {success} empleados importados")
                if failed > 0:
                    logger.warning(f"✗ {failed} empleados fallaron")
                    for error in result.get('data', {}).get('errors', []):
                        logger.error(f"  Row {error.get('row')}: {error.get('error')}")

                return {"success": True, "imported": success, "failed": failed}
            else:
                logger.error(f"Error importando empleados: {response.text}")
                return {"success": False, "error": response.text}

        except Exception as e:
            logger.error(f"Error procesando Excel: {e}")
            return {"success": False, "error": str(e)}

    def import_candidate(self, candidate: Dict) -> bool:
        """Importa un candidato a JokkenClaude-App"""
        try:
            payload = {
                "rirekisho_id": f"RIR-{str(candidate.get('id', 0)).zfill(5)}",
                "form_data": {
                    "full_name_kanji": candidate.get("full_name_kanji"),
                    "full_name_kana": candidate.get("full_name_kana"),
                    "date_of_birth": str(candidate.get("date_of_birth")) if candidate.get("date_of_birth") else None,
                    "gender": candidate.get("gender"),
                    "nationality": candidate.get("nationality"),
                    "email": candidate.get("email"),
                    "phone": candidate.get("phone"),
                    "address": candidate.get("address"),
                },
                "photo_data_url": candidate.get("photo_data_url")
            }

            response = requests.post(
                f"{self.api_url}/api/candidates/rirekisho/form",
                headers=self.headers,
                json=payload
            )

            if response.status_code == 201:
                logger.info(f"✓ {candidate.get('full_name_kanji')} importado")
                return True
            else:
                logger.error(f"✗ {candidate.get('full_name_kanji')}: {response.text}")
                return False

        except Exception as e:
            logger.error(f"Error importando candidato: {e}")
            return False

    def import_candidates(self, candidates: List[Dict]) -> Dict:
        """Importa múltiples candidatos"""
        successful = 0
        failed = 0

        for candidate in candidates:
            if self.import_candidate(candidate):
                successful += 1
            else:
                failed += 1

        logger.info(f"\nResumen candidatos:")
        logger.info(f"✓ {successful} importados")
        if failed > 0:
            logger.warning(f"✗ {failed} fallaron")

        return {"successful": successful, "failed": failed}


class DatabaseJPMigrator:
    """Orquestador principal de migración desde DATABASEJP"""

    def __init__(self, databasejp_path: str, api_url: str, token: str):
        self.databasejp_path = Path(databasejp_path)
        self.api_url = api_url
        self.token = token

        if not self.databasejp_path.exists():
            raise ValueError(f"Carpeta {databasejp_path} no existe")

        logger.info(f"Inicializando migración desde {self.databasejp_path}")

    def find_files(self) -> Dict[str, Optional[Path]]:
        """Busca archivos en DATABASEJP"""
        files = {
            "access_db": None,
            "excel_employees": None
        }

        # Buscar Access
        for ext in ['*.mdb', '*.accdb']:
            for file in self.databasejp_path.glob(ext):
                files["access_db"] = file
                logger.info(f"✓ Encontrado: {file.name}")
                break

        # Buscar Excel
        for ext in ['*.xlsx', '*.xls']:
            for file in self.databasejp_path.glob(ext):
                files["excel_employees"] = file
                logger.info(f"✓ Encontrado: {file.name}")
                break

        return files

    def run(self):
        """Ejecuta migración completa"""
        logger.info("\n" + "="*60)
        logger.info("INICIANDO MIGRACIÓN DESDE DATABASEJP")
        logger.info("="*60 + "\n")

        # Encontrar archivos
        files = self.find_files()

        if not files["access_db"] and not files["excel_employees"]:
            logger.error("✗ No se encontraron archivos en DATABASEJP")
            logger.info("Esperado:")
            logger.info("  - base_datos.mdb o base_datos.accdb")
            logger.info("  - empleados.xlsx o empleados.xls")
            return

        # Importar empleados
        if files["excel_employees"]:
            logger.info("\n" + "-"*60)
            logger.info("FASE 1: Importar Empleados")
            logger.info("-"*60 + "\n")

            importer = JokkenImporter(self.api_url, self.token)
            result = importer.import_employees_from_excel(str(files["excel_employees"]))

            if not result["success"]:
                logger.error(f"✗ Fallo importación de empleados: {result.get('error')}")
        else:
            logger.warning("⚠️ No se encontró archivo Excel de empleados")

        # Importar candidatos
        if files["access_db"]:
            logger.info("\n" + "-"*60)
            logger.info("FASE 2: Importar Candidatos con Fotos OLE")
            logger.info("-"*60 + "\n")

            try:
                # Leer Access
                reader = AccessDatabaseReader(str(files["access_db"]))
                candidates = reader.get_candidates_with_photos()

                if candidates:
                    # Importar candidatos
                    importer = JokkenImporter(self.api_url, self.token)
                    result = importer.import_candidates(candidates)
                else:
                    logger.error("✗ No se encontraron candidatos en Access")

            except ImportError as e:
                logger.error(f"✗ Error: {e}")
                logger.info("\nPara Windows con Access instalado:")
                logger.info("  pip install pyodbc")
                logger.info("\nDespués descarga:")
                logger.info("  https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255")

        logger.info("\n" + "="*60)
        logger.info("✓ MIGRACIÓN COMPLETADA")
        logger.info("="*60)


# Main
if __name__ == "__main__":
    # Configuración
    DATABASEJP_PATH = "/home/user/DATABASEJP"
    API_URL = "http://localhost:8000"
    TOKEN = None

    # Obtener token desde argumentos
    if len(sys.argv) > 1:
        TOKEN = sys.argv[1]
    else:
        logger.error("ERROR: Falta token API")
        logger.info("Uso: python3 migracion_databasejp.py <your_token>")
        logger.info("\nPara obtener token:")
        logger.info("  1. Abre http://localhost:3000")
        logger.info("  2. Login como admin")
        logger.info("  3. Copia el token API")
        sys.exit(1)

    # Ejecutar migración
    try:
        migrator = DatabaseJPMigrator(DATABASEJP_PATH, API_URL, TOKEN)
        migrator.run()
    except Exception as e:
        logger.error(f"Error fatal: {e}")
        sys.exit(1)
