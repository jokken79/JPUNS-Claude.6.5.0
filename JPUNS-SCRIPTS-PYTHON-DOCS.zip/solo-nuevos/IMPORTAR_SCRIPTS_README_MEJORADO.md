# 🚀 Scripts de Importación Mejorados - JokkenClaude-App 6.0.0

## 📋 Descripción General

Los scripts `.bat` ha sido completamente reescritos con estándares profesionales de UX/UI para Windows:

- ✅ **Menú interactivo visual** con opciones claras
- ✅ **Validaciones exhaustivas** antes de cada operación
- ✅ **Colores y símbolos** para mejor legibilidad
- ✅ **Progreso en tiempo real** de cada fase
- ✅ **Manejo robusto de errores** con soluciones específicas
- ✅ **Resumen final detallado** de resultados
- ✅ **Nunca se cierra** sin mostrar qué pasó

---

## 🎯 Scripts Disponibles

### 1. **IMPORTAR_INTELIGENTE.bat** ⭐ RECOMENDADO

**Descripción**: Script maestro con menú interactivo que maneja TODOS los tipos de importación

**Características**:
- Menú de selección numerado (1-5)
- Validaciones previas exhaustivas
- Manejo robusto de errores
- Importación secuencial automática
- Resumen visual de cada fase

**Uso Interactivo**:
```bash
IMPORTAR_INTELIGENTE.bat
```

Te mostrará un menú:
```
═══════════════════════════════════════════════════════════════════════════════════
                              MENÚ PRINCIPAL
═══════════════════════════════════════════════════════════════════════════════════

 OPCIONES DE IMPORTACIÓN:

   1) • CANDIDATOS        - Importar candidatos con fotos OLE
   2) • EMPLEADOS HAKEN  - Importar empleados dispatch
   3) • CONTRATISTAS UKEOI - Importar contratistas especializados
   4) • PERSONAL STAFF    - Importar personal de oficina
   5) • IMPORTACIÓN COMPLETA - Ejecutar todas en orden automático
   0) SALIR

Selecciona una opción (0-5):
```

**Uso por Línea de Comando** (automatizado):
```bash
REM Importar solo candidatos
IMPORTAR_INTELIGENTE.bat candidatos eyJhbGc...

REM Importar todo en secuencia
IMPORTAR_INTELIGENTE.bat todo eyJhbGc...
```

---

### 2. **IMPORTAR_CANDIDATOS.bat**

**Descripción**: Importar candidatos con fotos OLE desde Access automáticamente

**Flujo Visual**:
```
VALIDACIÓN 1: Verificando archivo migracion_databasejp.py
✓ migracion_databasejp.py encontrado

VALIDACIÓN 2: Verificando Python
✓ Python instalado: Python 3.11.0

VALIDACIÓN 3: Verificando carpeta DATABASEJP
✓ Carpeta encontrada: C:\Users\TuNombre\DATABASEJP

VALIDACIÓN 4: Buscando base de datos Access
✓ base_datos.mdb encontrado

PASO 1: Obtener Token API
───────────────────────────────────────────────────────────────────────────────────
→ Pega tu token API (Settings → API Token en http://localhost:3000)
Ingresa tu API Token: [eyJhbGc...]

✓ Token API obtenido (primeros 20 caracteres: eyJhbGciOiJIUzI1NiI...)

PASO 2: Validación Pre-importación
───────────────────────────────────────────────────────────────────────────────────
→ Verificando dependencias Python necesarias...

✓ Todas las dependencias disponibles

PASO 3: Ejecutar Importación
═════════════════════════════════════════════════════════════════════════════════════
                         IMPORTANDO CANDIDATOS...
═════════════════════════════════════════════════════════════════════════════════════

CONFIGURACIÓN:
  → Fuente: C:\Users\TuNombre\DATABASEJP\base_datos.mdb
  → Tabla: candidates
  → Fotos: Extracción OLE automática
  → Destino: JokkenClaude-App (API Token)

PROCESO EN EJECUCIÓN:
   1. Conectando a base de datos Access...
   2. Leyendo tabla de candidatos...
   3. Extrayendo fotos OLE a JPEG...
   4. Codificando a Base64...
   5. Importando a JokkenClaude-App...

═════════════════════════════════════════════════════════════════════════════════════
                    ✓ IMPORTACIÓN COMPLETADA EXITOSAMENTE
═════════════════════════════════════════════════════════════════════════════════════

RESUMEN:
  ✓ ✓ Candidatos importados correctamente
  ✓ ✓ Fotos OLE extraídas y procesadas
  ✓ ✓ Datos cargados en base de datos

PRÓXIMOS PASOS:
   1. Abre: http://localhost:3000
   2. Login: admin@example.com / admin_password_123
   3. Ve a: Reclutamiento → Candidatos
   4. Verifica que los candidatos aparecen CON FOTOS

WORKFLOW RECOMENDADO:
  → Evalúa cada candidato (Skills, experiencia, etc.)
  → Aprueba los candidatos seleccionados
  → Sistema auto-crea formularios NYUUSHA
  → Completa datos del empleado
  → Crea empleado final en sistema

═════════════════════════════════════════════════════════════════════════════════════
Presiona cualquier tecla para cerrar...
```

**Uso**:
```bash
REM Con menú para token
IMPORTAR_CANDIDATOS.bat

REM Con token como argumento (automatizado)
IMPORTAR_CANDIDATOS.bat eyJhbGciOiJIUzI1NiI...
```

---

## 🎨 Características Visuales

### Sistema de Colores
```
Cian (0B)      - Títulos principales y secciones importantes
Blanco (0F)    - Texto normal e instrucciones
Verde (0A)     - Estados ✓ (éxito, validación pasada)
Rojo (0C)      - Errores ✗ y situaciones críticas
Amarillo (0E)  - Advertencias ⚠️ e información importante
```

### Símbolos Utilizados
```
✓ CHECK        - Operación exitosa / Validación pasada
✗ CROSS        - Error / Validación fallida
→ ARROW        - Instrucción / Paso siguiente
• BULLET       - Ítem de lista
⏳ WAIT        - Procesamiento en curso
═══════        - Separador principal
━━━━━━━        - Separador secundario
```

---

## 🔍 Validaciones Automáticas

Cada script verifica automáticamente:

### 1. **Archivo Principal**
- ✓ `migracion_databasejp.py` existe
- ✓ Está en la carpeta correcta

### 2. **Python**
- ✓ Python está instalado
- ✓ Está en el PATH
- ✓ Versión compatible

### 3. **Dependencias Python**
- ✓ `pyodbc` instalado (para Access)
- ✓ `pandas` instalado (para Excel)
- ✓ `openpyxl` instalado (para Excel)
- ✓ `Pillow` instalado (para fotos)
- → Auto-instala si faltan

### 4. **Carpeta DATABASEJP**
- ✓ Existe en: `C:\Users\TuNombre\DATABASEJP`
- ✓ Contiene archivos requeridos

### 5. **Archivos de Datos**
- Para candidatos: `base_datos.mdb` (Access)
- Para empleados: `empleados.xlsx` (Excel)
- Para UKEOI: `ukeoi.xlsx` (Excel - opcional)
- Para STAFF: `staff.xlsx` (Excel - opcional)

### 6. **API Token**
- ✓ Token API válido
- ✓ Formato JWT correcto
- ✓ Acceso a servidor JokkenClaude-App

---

## 🚨 Manejo de Errores

Si algo falla, el script muestra:

1. **¿QUÉ falló?** (descripción clara)
2. **¿POR QUÉ?** (posibles causas)
3. **¿CÓMO lo arreglo?** (soluciones específicas)
4. **¿DÓNDE buscar ayuda?** (documentación + links)

**Ejemplo - Error: Base de datos Access usada por otro programa**:
```
╳ ERROR EN LA IMPORTACIÓN
═════════════════════════════════════════════════════════════════════════════════════

INFORMACIÓN DE ERROR:
  Revisa el log anterior para detalles específicos

POSIBLES CAUSAS:
  1. Base de datos Access está siendo usada por otro programa
  2. Archivo base_datos.mdb está corrupto
  3. Tabla 'candidates' no existe en la BD
  4. Token API es inválido o expirado
  5. Servidor JokkenClaude-App no está corriendo

SOLUCIONES:
  1. Cierra otros programas que usen la BD (Excel, Access)
  2. Verifica que la BD contiene la tabla 'candidates'
  3. Verifica que el servidor está corriendo: http://localhost:8000
  4. Obtén un nuevo token si el anterior expiró

DOCUMENTACIÓN:
  → docs/guides/DATABASEJP_IMPORT.md

═════════════════════════════════════════════════════════════════════════════════════

Presiona cualquier tecla para cerrar...
```

---

## 📝 Archivo de Estructura Requerida

### Carpeta DATABASEJP
```
C:\Users\TuNombre\DATABASEJP\
├── base_datos.mdb              ← Candidatos con fotos OLE
├── empleados.xlsx              ← Empleados HAKEN
├── ukeoi.xlsx                  ← Contratistas (opcional)
└── staff.xlsx                  ← Personal oficina (opcional)
```

### Estructura Excel (empleados.xlsx)

| Columna | Tipo | Ejemplo | Obligatorio |
|---------|------|---------|------------|
| full_name_kanji | Texto | 田中太郎 | Sí |
| full_name_kana | Texto | タナカタロウ | Sí |
| date_of_birth | Fecha | 1995-04-15 | Sí |
| gender | Texto | male/female | Sí |
| nationality | Texto | 日本 / Vietnam | Sí |
| hourly_rate | Número | 1000 (¥) | Sí |
| factory_id | Texto | TOYOTA_NAGOYA | Sí |
| visa_type | Texto | 技能実習 / 特定技能 | Sí |
| phone | Texto | 080-1234-5678 | No |
| email | Email | tanaka@example.com | No |

---

## 🔧 Obtener Token API

### Método 1: Desde la Interfaz Web
```
1. Abre: http://localhost:3000
2. Login: admin@example.com / admin_password_123
3. Click: Settings ⚙️  (esquina superior derecha)
4. Selecciona: API Token
5. Copia el token completo (formato: eyJhbGc...)
```

### Método 2: Desde Terminal (curl)
```bash
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin_password_123"

# Respuesta:
# {
#   "access_token": "eyJhbGciOiJIUzI1NiI...",
#   "refresh_token": "eyJhbGciOiJIUzI1NiI...",
#   "token_type": "bearer"
# }
```

**Token de Ejemplo**: (NO usar, crear uno nuevo)
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTczMDcwNDAwMCwiaWF0IjoxNzMwNjE3NjAwfQ.xYz1234...
```

---

## 📊 Tiempo de Ejecución Estimado

| Operación | Tiempo | Notas |
|-----------|--------|-------|
| Validaciones | 5-10s | Rápido |
| Candidatos (100+) | 2-5 min | Incluye OLE extraction |
| Empleados (100+) | 1-3 min | Lectura Excel + cálculos |
| UKEOI (50+) | 1-2 min | Opcional |
| STAFF (50+) | 1-2 min | Opcional |
| **Completa** | **5-15 min** | Todas las fases |

---

## 🐛 Troubleshooting

### Error: "Python no está instalado"
```
Solución:
  1. Descarga: https://www.python.org/downloads/
  2. IMPORTANTE: Marca "Add Python to PATH"
  3. Reinicia la terminal
  4. Verifica: python --version
```

### Error: "Base de datos está siendo usada"
```
Solución:
  1. Cierra Excel (cierra completamente, no solo la ventana)
  2. Cierra Microsoft Access
  3. Mata el proceso explorer si es necesario
  4. Reinicia y vuelve a intentar
```

### Error: "Token inválido"
```
Solución:
  1. Verifica que JokkenClaude-App está corriendo
  2. Obtén un nuevo token (el anterior puede haber expirado)
  3. Copia el token COMPLETO (sin espacios)
```

### Error: "Tabla 'candidates' no existe"
```
Solución:
  1. Abre base_datos.mdb en Access
  2. Verifica que existe tabla: candidates
  3. Verifica que tiene datos
  4. Si no, usa la estructura correcta (ver DATABASEJP_IMPORT.md)
```

---

## 💡 Mejores Prácticas

1. **Antes de importar**:
   - ✓ Cierra todos los archivos Excel/Access
   - ✓ Verifica que JokkenClaude-App está corriendo
   - ✓ Obtén un token API válido
   - ✓ Ten los archivos en la carpeta correcta

2. **Durante la importación**:
   - ✓ No cierres la ventana (espera a que termine)
   - ✓ Lee los mensajes de progreso
   - ✓ Si hay advertencias, nota los detalles

3. **Después de importar**:
   - ✓ Verifica que los datos aparecen en http://localhost:3000
   - ✓ Chequea fotos y datos personales
   - ✓ Sigue el workflow recomendado (evaluación → aprobación)

---

## 📚 Documentación Relacionada

- 📖 `docs/guides/DATABASEJP_IMPORT.md` - Importación desde Access/Excel
- 📖 `docs/guides/DATA_MIGRATION.md` - Migración general de datos
- 📖 `docs/guides/CANDIDATE_IMPORT.md` - Importación manual de candidatos
- 📖 `IMPORTAR_SCRIPTS_README.txt` - Guía técnica anterior

---

## ✅ Checklist de Verificación

Después de cada importación, verifica:

```
□ Datos aparecen en http://localhost:3000
□ Número de registros es correcto
□ Fotos se muestran correctamente (candidatos)
□ Información personal está completa
□ Salarios/rates están configurados
□ Asignaciones de fábrica son correctas
□ No hay registros duplicados
□ Códigos y referencias son válidos
```

---

## 🎯 Workflows Recomendados

### Workflow 1: Contratar Nuevo Candidato
```
1. IMPORTAR_CANDIDATOS.bat → Importa candidato
2. Sistema crea automáticamente NYUUSHA (入社連絡票)
3. Completa datos en NYUUSHA
4. Aprueba NYUUSHA → Automáticamente crea EMPLEADO
5. Asigna apartamento y configura nómina
```

### Workflow 2: Importar Lotes de Empleados
```
1. IMPORTAR_INTELIGENTE.bat → Selecciona "Importación Completa"
2. Sistema importa en orden: Candidatos → Empleados → UKEOI → STAFF
3. Verifica cada lote en http://localhost:3000
4. Realiza ajustes manuales si es necesario
```

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0 (Mejorada)
**Estado**: ✅ Producción
