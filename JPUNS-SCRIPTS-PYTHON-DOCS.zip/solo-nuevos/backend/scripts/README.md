# Backend Scripts - Administration & Utilities

Scripts de administración, validación e inicialización de la base de datos para JokkenClaude-App.

---

## 🚀 Scripts Críticos

### 1. **init_db.py** - Inicializar Base de Datos

```bash
python init_db.py
```

- Crea tablas base si no existen
- Ejecuta migrations de Alembic
- Inicializa esquema de base de datos

**Uso**: Primera vez que instalas la aplicación o después de un reset de BD

---

### 2. **create_admin_user.py** - Crear Usuario Administrador

```bash
python create_admin_user.py
```

- Crea usuario admin por defecto
- Usuario: `admin@example.com`
- Contraseña: `admin_password_123`

**Uso**: Si el usuario admin se elimina o necesitas recrearlo

---

### 3. **import_data.py** - Importar Datos Masivamente

```bash
python import_data.py [tipo_datos] [archivo.xlsx] [opciones]
```

Ejemplos:
```bash
python import_data.py employees employees.xlsx
python import_data.py candidates candidates.xlsx
python import_data.py factories factories.xlsx
```

- Importación desde múltiples formatos
- Validación de datos
- Error handling robusto

**Uso**: Importar datos en lote desde Excel o bases de datos externas

---

### 4. **validate_system.py** - Validar Sistema Completo

```bash
python validate_system.py
```

Verifica:
- ✓ Conectividad a base de datos
- ✓ Estructura de tablas
- ✓ Integridad de datos
- ✓ Configuración del sistema
- ✓ APIs funcionando

**Uso**: Diagnosticar problemas, post-instalación

---

### 5. **seed_salary_data.py** - Cargar Datos de Nómina

```bash
python seed_salary_data.py
```

- Carga datos de ejemplo de nómina
- Crea escalas salariales
- Inicializa configuración de impuestos

**Uso**: Configuración inicial del sistema de nómina

---

## 📸 Photo Processing Scripts

### **sync_employee_photos.py**
Sincronizar fotos de empleados desde múltiples fuentes.

```bash
python sync_employee_photos.py
```

### **sync_candidate_photos.py**
Sincronizar fotos de candidatos.

```bash
python sync_candidate_photos.py
```

### **fix_employee_photos.py**
Reparar o corregir fotos de empleados problemáticas.

```bash
python fix_employee_photos.py
```

### **auto_extract_photos_from_databasejp_v2.py** (ADVANCED)
Extracción automática y avanzada de fotos OLE de Access.

```bash
python auto_extract_photos_from_databasejp_v2.py [archivo.mdb]
```

**Nota**: Más robusto que `migracion_databasejp.py` para casos especiales

---

## 📚 Documentación Incluida

- **IMPORTACION_COMPLETA.md** - Guía completa de importación de datos
- **IMPLEMENTATION_SUMMARY.md** - Resumen de implementación
- **SEED_SALARY_README.md** - Documentación de seed de nómina

---

## ⚙️ Configuración Necesaria

Antes de ejecutar scripts, asegurate de:

1. **Virtualenv activado**:
   ```bash
   source venv/bin/activate  # Linux/Mac
   # o
   venv\Scripts\activate      # Windows
   ```

2. **Variables de entorno configuradas**:
   ```bash
   export DATABASE_URL="postgresql://usuario:password@localhost/dbname"
   export REDIS_URL="redis://localhost:6379"
   ```

3. **Dependencias instaladas**:
   ```bash
   pip install -r requirements.txt
   ```

---

## 🔍 Troubleshooting

### "ModuleNotFoundError: No module named 'app'"

**Solución**: Ejecuta desde el directorio `backend/`:
```bash
cd /path/to/backend
python scripts/script_name.py
```

### "DatabaseError: Connection refused"

**Solución**: Verifica que PostgreSQL está corriendo:
```bash
docker compose up -d db
```

### "Permission denied" en scripts

**Solución**: Hacer ejecutables:
```bash
chmod +x script_name.py
./script_name.py
```

---

## 📝 Logs

Los scripts generan logs detallados en:
- `logs/` directory
- Console output (si está configurado)

Revisa logs para debugging de problemas.

---

## 🚀 Próximos Pasos

1. **Primero**: `python init_db.py` - Inicializar BD
2. **Segundo**: `python create_admin_user.py` - Crear admin
3. **Tercero**: `python validate_system.py` - Validar todo
4. **Cuarto**: Importar datos según sea necesario

---

**Última actualización**: 2025-11-22
**Versión**: 1.0.0
